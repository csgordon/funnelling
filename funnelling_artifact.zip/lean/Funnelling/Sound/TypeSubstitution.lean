import Funnelling.Sound.RenamingTyping

open Funnelling.SoundSimp

namespace Funnelling

abbrev GOk (d : Decls) (Delta : Bounds) (s : GSubst) : Prop :=
  forall b, List.Mem b Delta -> forall G, List.lookup b.X s = some G ->
    Sub d [] G.ty (b.T.subst s.ty) /\ Kind d [] G.ty /\ Kind d [] (b.T.subst s.ty)

abbrev gsubB (s : GSubst) (Delta : Bounds) : Bounds :=
  Bounds.subst s.ty (Delta.filter fun b => !((s.map Prod.fst).contains b.X))

abbrev gsubG (s : GSubst) (Gamma : TypeEnv) : TypeEnv := Gamma.map (VarDecl.subst s.ty)

theorem GOk.substCtx {d : Decls} {Delta : Bounds} {s : GSubst} (h : GOk d Delta s) :
    SubstCtx d Delta (gsubB s Delta) s.ty := by
  intro b hb
  cases hl : List.lookup b.X s with
  | none =>
    refine Or.inl (Exists.intro b.X (And.intro ?_ ?_))
    . simp only [Ty.subst, GSubst.lookup_ty, hl, Option.map_none, Option.getD_none]
    . simp only [gsubB, Bounds.subst, listMem_iff, List.mem_map, List.mem_filter]
      refine Exists.intro b (And.intro (And.intro hb ?_) rfl)
      simpa using lookup_none_not_dom hl
  | some G =>
    have hg := h b hb G hl
    have e : (Ty.var b.X).subst s.ty = G.ty := by
      simp only [Ty.subst, GSubst.lookup_ty, hl, Option.map_some, Option.getD_some]
    rw [e]
    have hG := hg.2.1
    cases G with
    | cls C Gs =>
      refine Or.inr (And.intro (Sub.cls_indep hg.1) (And.intro (Kind.mono (fun _ h => by cases h) hg.2.1)
        (Kind.mono (fun _ h => by cases h) hg.2.2)))

theorem GOk.append {d : Decls} {Delta Dm : Bounds} {s : GSubst} (h : GOk d Delta s)
    (hm : forall b, List.Mem b Dm -> Not (List.Mem b.X (s.map Prod.fst))) : GOk d (Delta ++ Dm) s := by
  intro b hb G hl
  exact (List.mem_append.mp hb).elim (fun hb => h b hb G hl) (fun hb => absurd (lookup_some_mem_dom hl) (hm b hb))

theorem GOk.mono {d : Decls} {Delta Delta2 : Bounds} {s : GSubst} (h : GOk d Delta s) (hs : Sub1 Delta2 Delta) :
    GOk d Delta2 s := fun b hb => h b (hs b hb)

theorem gsubB_append {s : GSubst} {Delta Dm : Bounds}
    (hm : forall b, List.Mem b Dm -> Not (List.Mem b.X (s.map Prod.fst))) :
    gsubB s (Delta ++ Dm) = gsubB s Delta ++ Bounds.subst s.ty Dm := by
  simp only [gsubB, List.filter_append, Bounds.subst, List.map_append]
  congr 2
  apply List.filter_eq_self.mpr
  intro b hb
  simpa using hm b hb

theorem TypeEnv.lookup_gsubG {s : GSubst} {x : VarName} {T : Ty} : forall {Gamma : TypeEnv}, Gamma.lookup x = some T ->
    (gsubG s Gamma).lookup x = some (T.subst s.ty)
  | [], h => by simp [TypeEnv.lookup] at h
  | y :: Gamma, h => by
    by_cases hy : y.x = x
    . simp only [TypeEnv.lookup, List.find?_cons, hy, beq_self_eq_true, Option.map_some] at h |-
      simp only [gsubG, List.map_cons, List.find?_cons, VarDecl.subst, hy, beq_self_eq_true, Option.map_some]
      cases h
      rfl
    . have hb : (y.x == x) = false := by simpa using hy
      simp only [TypeEnv.lookup, List.find?_cons, hb] at h |-
      simp only [gsubG, List.map_cons, List.find?_cons, VarDecl.subst, hb]
      exact TypeEnv.lookup_gsubG (Gamma := Gamma) h

theorem gdom_gsubG {s : GSubst} {Gamma : TypeEnv} : gdom (gsubG s Gamma) = gdom Gamma := by
  simp [gdom, gsubG, VarDecl.subst, List.map_map, Function.comp_def]

theorem substList_app {s : TSubst} {Ts Us : List Ty} :
    Ty.substList s (Ts ++ Us) = Ty.substList s Ts ++ Ty.substList s Us := by
  simp [substList_eq_map]

theorem cod_subst {s : TSubst} {Dm : Bounds} : cod (Bounds.subst s Dm) = Ty.substList s (cod Dm) := by
  simp [cod, Bounds.subst, substList_eq_map, List.map_map, Function.comp_def]

theorem params_T_subst {s : TSubst} {ps : List VarDecl} :
    (ps.map (VarDecl.subst s)).map VarDecl.T = Ty.substList s (ps.map VarDecl.T) := by
  simp [VarDecl.subst, substList_eq_map, List.map_map, Function.comp_def]

theorem KindSeq.substC {d : Decls} (hd : DeclOk d) {Delta Delta' : Bounds} {s : TSubst} (hc : SubstCtx d Delta Delta' s)
    {Ts : List Ty} (h : KindSeq d Delta Ts) : KindSeq d Delta' (Ty.substList s Ts) := by
  intro T hT
  rw [substList_eq_map] at hT
  rcases List.mem_map.mp hT with ⟨U, hU⟩; rw [<- hU.2]; exact Kind.subst hd hc.sub hc.kind (h U hU.1)

theorem var_gsubst_none {X : TVarName} {s : GSubst} (h : Not (List.Mem X (s.map Prod.fst))) :
    (Ty.var X).subst s.ty = Ty.var X := by
  simp only [Ty.subst, GSubst.lookup_ty, lookup_none_of_not_dom h, Option.map_none, Option.getD_none]

theorem var_gsubst_some {X : TVarName} {s : GSubst} {G : GTy} (h : List.lookup X s = some G) :
    (Ty.var X).subst s.ty = G.ty := by
  simp only [Ty.subst, GSubst.lookup_ty, h, Option.map_some, Option.getD_some]

theorem GOk.of_bounds {d : Decls} (hd : DeclOk d) {Delta : Bounds} {s : GSubst}
    (hb : forall b, List.Mem b Delta ->
      Sub d [] ((Ty.var b.X).subst s.ty) (b.T.subst s.ty) /\ Kind d [] ((Ty.var b.X).subst s.ty))
    (hK : forall b, List.Mem b Delta -> Kind d Delta b.T) : GOk d Delta s := by
  intro b hbm G hl
  have hk := hb b hbm
  rw [var_gsubst_some hl] at hk
  exact And.intro hk.1 (And.intro hk.2 (Kind.subst hd (fun b h => (hb b h).1) (fun b h => (hb b h).2) (hK b hbm)))

theorem abs_gsubst {s : GSubst} : forall {Fs : List Funnel}, abs (Fs.map (Funnel.gsubst s)) = Ty.substList s.ty (abs Fs)
  | [] => rfl
  | F :: Fs => by
    have ih := abs_gsubst (s := s) (Fs := Fs)
    simp only [abs, List.map_cons, Ty.substList] at ih |-
    rw [ih]
    congr 1
    cases F with
    | ground G => simp only [Funnel.gsubst, Funnel.abs]; exact (GTy.subst_ty G).symm
    | funnel X =>
      cases hl : List.lookup X s with
      | none => simp only [Funnel.gsubst, hl, Funnel.abs, Ty.subst, GSubst.lookup_ty, Option.map_none, Option.getD_none]
      | some G => simp only [Funnel.gsubst, hl, Funnel.abs]; exact (var_gsubst_some hl).symm

mutual
theorem Ty.ftv_gsubst {s : GSubst} {X : TVarName} : forall {T : Ty}, List.Mem X (T.subst s.ty).ftv ->
    List.Mem X T.ftv /\ Not (List.Mem X (s.map Prod.fst))
  | .var Y, h => by
    cases hl : List.lookup Y s with
    | none =>
      have hY : Not (List.Mem Y (s.map Prod.fst)) := fun hm => by
        cases lookup_isSome hm with | intro v hv => rw [hv] at hl; cases hl
      rw [var_gsubst_none hY] at h
      have e : X = Y := by simpa [Ty.ftv] using h
      subst e
      exact And.intro h hY
    | some G => rw [var_gsubst_some hl, GTy.ftv_ty] at h; cases h
  | .cls C Ts, h => Ty.ftvList_gsubst h
theorem Ty.ftvList_gsubst {s : GSubst} {X : TVarName} : forall {Ts : List Ty},
    List.Mem X (Ty.ftvList (Ty.substList s.ty Ts)) -> List.Mem X (Ty.ftvList Ts) /\ Not (List.Mem X (s.map Prod.fst))
  | [], h => by cases h
  | T :: Ts, h => by
    simp only [Ty.substList, Ty.ftvList, listMem_iff, List.mem_append] at h |-
    rcases h with h | h
    . have := Ty.ftv_gsubst h; exact And.intro (Or.inl this.1) this.2
    . have := Ty.ftvList_gsubst h; exact And.intro (Or.inr this.1) this.2
end

mutual
theorem Ty.ftv_gsubst_back {s : GSubst} {X : TVarName} : forall {T : Ty}, List.Mem X T.ftv ->
    Not (List.Mem X (s.map Prod.fst)) -> List.Mem X (T.subst s.ty).ftv
  | .var Y, h, hX => by
    have e : X = Y := by simpa [Ty.ftv] using h
    subst e
    rw [var_gsubst_none hX]
    exact h
  | .cls C Ts, h, hX => Ty.ftvList_gsubst_back h hX
theorem Ty.ftvList_gsubst_back {s : GSubst} {X : TVarName} : forall {Ts : List Ty},
    List.Mem X (Ty.ftvList Ts) -> Not (List.Mem X (s.map Prod.fst)) -> List.Mem X (Ty.ftvList (Ty.substList s.ty Ts))
  | [], h, _ => by cases h
  | T :: Ts, h, hX => by
    simp only [Ty.substList, Ty.ftvList, listMem_iff, List.mem_append] at h |-
    rcases h with h | h
    . exact Or.inl (Ty.ftv_gsubst_back h hX)
    . exact Or.inr (Ty.ftvList_gsubst_back h hX)
end

theorem substList_subst_gen {s s' : TSubst} {L : List Ty}
    (h : forall X, List.Mem X (Ty.ftvList L) -> List.Mem X (s.map Prod.fst)) :
    Ty.substList s' (Ty.substList s L) = Ty.substList (s.map fun p => (p.1, p.2.subst s')) L :=
  Ty.substList_comp (fun X hX => var_subst_comp_of_some (lookup_isSome (h X hX)))

theorem vars_gsubst {s : GSubst} {Xs : List TVarName} (h : forall X, List.Mem X Xs -> Not (List.Mem X (s.map Prod.fst))) :
    Ty.substList s.ty (vars Xs) = vars Xs := by
  apply Ty.substList_id
  intro X hX
  apply var_gsubst_none
  apply h
  rcases Ty.mem_ftvList.mp hX with ⟨T, hT⟩
  simp only [vars, listMem_iff, List.mem_map] at hT
  rcases hT.1 with ⟨Y, hY⟩; rw [<- hY.2] at hT; have := hT.2; simp [Ty.ftv] at this; rw [this]; exact hY.1

theorem Sub.cls_target {d : Decls} {Delta : Bounds} {T1 T : Ty} (h : Sub d Delta T1 T) :
    forall {C Ts}, T1 = .cls C Ts -> exists C' Ts', T = .cls C' Ts' := by
  induction h with
  | subRefl => intro C Ts e; exact Exists.intro C (Exists.intro Ts e)
  | subInherit _ _ _ ih => intro _ _ _; exact ih (C := _) (Ts := _) (by simp only [Ty.subst]; rfl)
  | subInheritLocal _ _ _ _ ih => intro _ _ _; exact ih (C := _) (Ts := _) (by simp only [Ty.subst]; rfl)
  | subVar _ _ _ => intro _ _ e; cases e

theorem names_gsubst {s : GSubst} : forall {Ms : List Method}, (Method.gsubstList s Ms).map Method.name = Ms.map Method.name
  | [] => rfl
  | M :: Ms => by
    cases M with
    | mk Dm T0 m ps e => simp only [Method.gsubstList, Method.gsubst, List.map_cons, Method.name]; rw [names_gsubst]

theorem OverrideOkM.gsubst {d : Decls} (hwf : WFDecls d) (hok : DeclsOk d) {s : GSubst} {C : ClassName}
    {Us : List Ty} {M : Method} (h : OverrideOkM d (.cls C Us) M)
    (hdis : forall X, List.Mem X (dom M.Delta) -> Not (List.Mem X (s.map Prod.fst))) :
    OverrideOkM d (.cls C (Ty.substList s.ty Us)) (M.gsubst s) := by
  cases M with
  | mk Dp T0p m psp ep =>
    simp only [Method.Delta] at hdis
    have hv := vars_gsubst hdis
    cases h with
    | absent h1 h2 => exact OverrideOkM.absent h1 h2
    | @found _ _ Dl0 _ _ _ _ _ Do T0o pso eo h1 h2 h3 h4 h5 h6 =>
      have hcl := methodIn_closed hwf hok h2 h1
      have hlen : (Us ++ vars (dom Dp)).length = (Dl0 ++ Do).length := by simp [h3, h4, vars, dom]
      refine OverrideOkM.found h1 h2 (by rw [substList_length, h3])
        (by simp only [Bounds.subst, List.length_map]; exact h4) ?_ ?_
      . rw [dom_bounds_subst, cod_subst, <- h5, substList_bind_comp hlen hcl.2, substList_app, hv]
      . have e := congrArg (Ty.substList s.ty) h6
        rw [substList_bind_comp hlen hcl.1, substList_app, hv] at e
        rw [dom_bounds_subst, e, Ty.substList, params_T_subst]

theorem gsubB_cons_none {s : GSubst} {b : Bound} {Delta : Bounds} (h : Not (List.Mem b.X (s.map Prod.fst))) :
    gsubB s (b :: Delta) = { X := b.X, T := b.T.subst s.ty } :: gsubB s Delta := by
  have : ((s.map Prod.fst).contains b.X) = false := by simpa using h
  simp only [gsubB, List.filter_cons, this, Bool.not_false, ite_true, Bounds.subst, List.map_cons]

theorem gsubB_cons_some {s : GSubst} {b : Bound} {Delta : Bounds} (h : List.Mem b.X (s.map Prod.fst)) :
    gsubB s (b :: Delta) = gsubB s Delta := by
  have : ((s.map Prod.fst).contains b.X) = true := by simpa using h
  simp only [gsubB, List.filter_cons, this, Bool.not_true]
  rfl

theorem mem_gsubB {s : GSubst} {Delta : Bounds} {b : Bound} (hb : List.Mem b Delta)
    (h : Not (List.Mem b.X (s.map Prod.fst))) : List.Mem { X := b.X, T := b.T.subst s.ty } (gsubB s Delta) := by
  simp only [gsubB, Bounds.subst, listMem_iff, List.mem_map, List.mem_filter]
  exact Exists.intro b (And.intro (And.intro hb (by simpa using h)) rfl)

theorem RestrictB.gsub {s : GSubst} {Delta : Bounds} {Fs : List Funnel} {Delta' : Bounds}
    (h : RestrictB Delta Fs Delta') : RestrictB (gsubB s Delta) (Fs.map (Funnel.gsubst s)) (gsubB s Delta') := by
  induction h with
  | nil => exact RestrictB.nil
  | @funnel X T Fs Delta' hm _ ih =>
    cases hl : List.lookup X s with
    | none =>
      have hX : Not (List.Mem X (s.map Prod.fst)) := fun hm' => by
        cases lookup_isSome hm' with | intro v hv => rw [hv] at hl; cases hl
      rw [gsubB_cons_none (b := { X := X, T := T }) hX]
      simp only [List.map_cons, Funnel.gsubst, hl]
      exact RestrictB.funnel (mem_gsubB (b := { X := X, T := T }) hm hX) ih
    | some G =>
      rw [gsubB_cons_some (b := { X := X, T := T }) (lookup_some_mem_dom hl)]
      simp only [List.map_cons, Funnel.gsubst, hl]
      exact RestrictB.ground ih
  | ground _ ih => exact RestrictB.ground ih

theorem innerG_gsub_sub {s : GSubst} {Gamma : TypeEnv} {Fs : List Funnel} {C : ClassName} :
    Sub1 (gsubG s (innerG Gamma Fs C)) (innerG (gsubG s Gamma) (Fs.map (Funnel.gsubst s)) C) := by
  intro y hy
  simp only [innerG, gsubG, withoutThis, restrict, listMem_iff, List.map_append, List.mem_append, List.mem_map,
    List.mem_filter, List.map_cons, List.map_nil, List.mem_singleton] at hy |-
  rcases hy with hy | hy
  . rcases hy with ⟨z, hz⟩
    refine Or.inl (And.intro (And.intro (Exists.intro z (And.intro hz.1.1.1 hz.2)) ?_) ?_)
    . rw [<- hz.2, List.all_eq_true]
      intro X hX
      have hA := hz.1.1.2
      rw [List.all_eq_true] at hA
      have h1 := Ty.ftv_gsubst (s := s) (T := z.T) (by simpa [VarDecl.subst] using hX)
      have h2 := hA X h1.1
      simp only [List.contains_iff_mem] at h2 |-
      rw [abs_gsubst]
      exact Ty.ftvList_gsubst_back h2 h1.2
    . rw [<- hz.2]; simpa [VarDecl.subst] using hz.1.2
  . refine Or.inr ?_
    rw [hy]
    simp only [VarDecl.subst, Ty.subst, abs_gsubst]

theorem Consistent.gsub {d : Decls} (hwf : WFDecls d) (hok : DeclsOk d) (hd : DeclOk d) {s : GSubst}
    {C : ClassName} {Fs : List Funnel} {C0 : ClassName} {Ts : List Ty} {es es' : List Expr} {Ms : List Method}
    (h : Consistent d (.newLocal C Fs C0 Ts es Ms))
    (hdis : forall M, List.Mem M Ms -> forall X, List.Mem X (dom M.Delta) -> Not (List.Mem X (s.map Prod.fst))) :
    Consistent d (.newLocal C (Fs.map (Funnel.gsubst s)) C0 (Ty.substList s.ty Ts) es' (Method.gsubstList s Ms)) := by
  rcases consistent_unfold h with ⟨Fs', Ts', es'', Ms'', Delta0, h1, h2, h3, h4, h5, h6⟩
  have hcl := hd.supL _ _ _ _ _ _ _ h1 h2
  refine ⟨Fs', Ts', es'', Ms'', Delta0, h1, h2, by simp [h3], ?_, ?_, ?_⟩
  . rw [abs_gsubst, h4, substList_subst_gen (fun X hX => by
      cases bind_lookup_some (Us := abs Fs) (by rw [abs_length]; exact h3) (hcl X hX) with
      | intro U hU => exact lookup_some_mem_dom hU), <- bind_map, <- substList_eq_map]
  . intro m; rw [names_gsubst]; exact h5 m
  . intro M' hM'
    rw [abs_gsubst]
    cases Method.gsubstList_mem hM' with
    | intro M hM => rw [hM.2]; exact OverrideOkM.gsubst hwf hok (h6 M hM.1) (hdis M hM.1)

theorem OverrideOk.gsub {d : Decls} (hwf : WFDecls d) (hok : DeclsOk d) (hd : DeclOk d) {s : GSubst}
    {Delta Delta2 : Bounds} {C0 : ClassName} {Ts : List Ty} {Ms : List Method} (h : OverrideOk d Delta (.cls C0 Ts) Ms)
    (hdis : forall M, List.Mem M Ms -> forall X, List.Mem X (dom M.Delta) -> Not (List.Mem X (s.map Prod.fst))) :
    OverrideOk d Delta2 (.cls C0 (Ty.substList s.ty Ts)) (Method.gsubstList s Ms) := by
  intro M' C' Ts' hM' hs
  rcases Method.gsubstList_mem hM' with ⟨M, hM⟩
  rw [hM.2]
  rcases Sub.inv_subst hd (Delta2 := Delta) (A := Ty.ftvList Ts) hs rfl (fun _ h => h) with ⟨T0, h0⟩
  rcases Sub.cls_target h0.2.1 rfl with ⟨C1, U0, e0⟩
  subst e0
  have e := h0.1
  simp only [Ty.subst, Ty.cls.injEq] at e
  have e1 := e.1
  subst e1
  rw [e.2]
  exact OverrideOkM.gsubst hwf hok (h M C' U0 hM.1 h0.2.1) (hdis M hM.1)

theorem dom_mem_tbinders {X : TVarName} : forall {M : Method}, List.Mem X (dom M.Delta) -> List.Mem X M.tbinders
  | .mk _ _ _ _ _, h => by
    simp only [Method.tbinders, listMem_iff, List.mem_append]
    exact Or.inl h

theorem Typing.gsub_newLocal {d : Decls} (hwf : WFDecls d) (hok : DeclsOk d) (hd : DeclOk d) {Delta : Bounds}
    {Gamma : TypeEnv} {C : ClassName} {Fs : List Funnel} {C0 : ClassName} {Ts : List Ty} {es : List Expr}
    {Ms : List Method} {Delta' : Bounds} {T'' : Ty} {s : GSubst} {Xs : List TVarName}
    {xs : List VarName}
    (h1 : Consistent d (.newLocal C Fs C0 Ts es Ms)) (h2 : RestrictB Delta Fs Delta')
    (h3 : forall X, List.Mem X (Ty.ftvList (cod Delta')) -> List.Mem X (dom Delta'))
    (h4 : Kind d Delta' (.cls C (abs Fs))) (h5 : Kind d Delta' (.cls C0 Ts))
    (h8 : OverrideOk d Delta' (.cls C0 Ts) Ms)
    (ih6 : Typing d (gsubB s Delta) (gsubG s Gamma) ((Expr.new C0 Ts es).gsubst s) (T''.subst s.ty))
    (ih7 : forall M, List.Mem M Ms -> MethodOk d (gsubB s Delta') (gsubG s (innerG Gamma Fs C)) (M.gsubst s))
    (hg : GOk d Delta s)
    (hdis : forall X, List.Mem X (Expr.newLocal C Fs C0 Ts es Ms).tbinders -> Not (List.Mem X (s.map Prod.fst)))
    (n1 : (gdom Gamma).Nodup) (sc : Sub1 (gdom Gamma) xs) (hn : (Expr.newLocal C Fs C0 Ts es Ms).noShadow Xs xs = true)
    (ht : NoThis (Expr.newLocal C Fs C0 Ts es Ms)) (hu : (Expr.newLocal C Fs C0 Ts es Ms).uniq) :
    Typing d (gsubB s Delta) (gsubG s Gamma) ((Expr.newLocal C Fs C0 Ts es Ms).gsubst s)
      ((Ty.cls C (abs Fs)).subst s.ty) := by
  simp only [Expr.noShadow, Bool.and_eq_true, Expr.tbinders, listMem_iff, List.mem_append, NoThis, Expr.vbinders,
    not_or, Expr.uniq] at hn hdis ht hu
  have hdisM : forall M, List.Mem M Ms -> forall X, List.Mem X (dom M.Delta) -> Not (List.Mem X (s.map Prod.fst)) :=
    fun M hM X hX => hdis X (Or.inr (Method.mem_tbindersList hM (dom_mem_tbinders hX)))
  have hg' := hg.mono h2.sub
  have sc' := hg'.substCtx
  simp only [Expr.gsubst] at ih6 |-
  simp only [Ty.subst]
  rw [<- abs_gsubst]
  have hp := RestrictB.gsub (s := s) h2
  refine Typing.newLocal (Consistent.gsub hwf hok hd h1 hdisM) hp ?_ ?_ ?_ ih6 ?_ (OverrideOk.gsub hwf hok hd h8 hdisM)
  . intro X hX
    rw [cod_subst] at hX
    have h1' := Ty.ftvList_gsubst hX
    have h2' : List.Mem X (dom Delta') := by
      apply h3
      rcases Ty.mem_ftvList.mp h1'.1 with ⟨T, hT⟩
      refine Ty.mem_ftvList.mpr (Exists.intro T (And.intro ?_ hT.2))
      simp only [cod, listMem_iff, List.mem_map, List.mem_filter] at hT |-
      rcases hT.1 with ⟨b, hb⟩; exact Exists.intro b (And.intro hb.1.1 hb.2)
    simp only [dom, listMem_iff, List.mem_map] at h2'
    rcases h2' with ⟨b, hb⟩
    have := mem_gsubB (s := s) hb.1 (by rw [hb.2]; exact h1'.2)
    rw [<- hb.2]
    show List.Mem (({ X := b.X, T := Ty.subst s.ty b.T } : Bound).X) (dom (gsubB s Delta'))
    exact List.mem_map_of_mem (f := Bound.X) this
  . have := Kind.subst hd sc'.sub sc'.kind h4
    rw [abs_gsubst]
    exact this
  . have := Kind.subst hd sc'.sub sc'.kind h5
    exact this
  . intro M' hM'
    rcases Method.gsubstList_mem hM' with ⟨M, hM⟩
    rw [hM.2]
    have hnM := Method.noShadowList_mem hM.1 hn.2
    have htM : NoThisM M := fun h => ht.2 (Method.mem_vbindersList hM.1 h)
    have hmo := MethodOk.vmap (ih7 M hM.1) (n := []) (fun _ h => h) (fun y hy => innerG_gsub_sub y (List.mem_filter.mp hy).1)
      (innerG_nodup (by rw [gdom_gsubG]; exact n1) _ _) (fun _ _ _ h => by cases h) (fun _ _ h => by cases h)
      (by rw [gdom_gsubG]; exact innerG_nodup n1 _ _) (by rw [gdom_gsubG]; exact innerG_dom sc _ _)
      (innerG_dom (by rw [gdom_gsubG]; exact sc) _ _) (by rw [Method.noShadow_gsubst]; exact hnM)
      (by rw [Method.vsubst_nil, Method.noShadow_gsubst]; exact hnM)
      (by simp only [NoThisM]; rw [Method.vbinders_gsubst]; exact htM)
      (by rw [Method.uniq_gsubst]; exact Method.uniqList_mem hM.1 hu.2) (fun _ h => by cases h)
    rwa [Method.vsubst_nil] at hmo

mutual
theorem Typing.gsub {d : Decls} (hwf : WFDecls d) (hok : DeclsOk d) (hd : DeclOk d) :
    forall {Delta Gamma e T}, Typing d Delta Gamma e T ->
    forall {s Xs xs}, GOk d Delta s -> (forall X, List.Mem X e.tbinders -> Not (List.Mem X (s.map Prod.fst))) ->
    (gdom Gamma).Nodup -> Sub1 (gdom Gamma) xs -> e.noShadow Xs xs = true -> NoThis e -> e.uniq ->
    Typing d (gsubB s Delta) (gsubG s Gamma) (e.gsubst s) (T.subst s.ty)
  | _, _, _, _, .subs h hk hs, _, _, _, hg, hdis, n1, sc, hn, ht, hu =>
    Typing.subs (Typing.gsub hwf hok hd h hg hdis n1 sc hn ht hu) (Kind.subst hd hg.substCtx.sub hg.substCtx.kind hk)
      (Sub.subst hd hg.substCtx.sub hs)
  | _, _, _, _, .var hl, _, _, _, _, _, _, _, _, _, _ => Typing.var (TypeEnv.lookup_gsubG hl)
  | _, _, _, _, .newObject, _, _, _, _, _, _, _, _, _, _ => Typing.newObject
  | _, _, _, _, .field h1 h2 h3 h4, s, _, _, hg, hdis, n1, sc, hn, ht, hu => by
    have ih := Typing.gsub hwf hok hd h1 hg hdis n1 sc hn ht hu
    rw [subst_bind_comp h4 (field_closed hok h2 h3)]
    exact Typing.field ih h2 h3 (by rw [substList_length, h4])
  | _, _, _, _, .call (Delta0 := Delta0) (Delta1 := Delta1) (Ts0 := Ts0) (Ts1 := Ts1) h1 h2 h3 h4 h5 h6 h7 h8 h9, s, _, _,
      hg, hdis, n1, sc, hn, ht, hu => by
    simp only [Expr.noShadow, Bool.and_eq_true, Expr.tbinders, listMem_iff, List.mem_append, NoThis, Expr.vbinders,
      not_or, Expr.uniq] at hn hdis ht hu
    have hcl := methodIn_closed hwf hok h2 h3
    have ih1 := Typing.gsub hwf hok hd h1 hg (fun X hX => hdis X (Or.inl hX)) n1 sc hn.1 ht.1 hu.1
    have ih2 := TypingSeq.gsub hwf hok hd h9 hg (fun X hX => hdis X (Or.inr hX)) n1 sc hn.2 ht.2 hu.2
    have hlen : (Ts0 ++ Ts1).length = (Delta0 ++ Delta1).length := by simp [h4, h5]
    have e6 := congrArg (Ty.substList s.ty) h6
    rw [substList_bind_comp hlen hcl.1, substList_app] at e6
    refine Typing.call ih1 h2 h3
      (by rw [substList_length, h4]) (by rw [substList_length, h5]) e6
      (KindSeq.substC hd hg.substCtx h7) ?_ ih2
    have := SubSeq.subst hd hg.substCtx.sub h8
    rwa [substList_bind_comp hlen hcl.2, substList_app] at this
  | _, _, _, _, .superCall (D0 := D0) (Ts0 := Ts0) (Delta1 := Delta1) (Ts1 := Ts1) h1 h2 h3 h4 h5 h6 h7 h8 h9 h10 h11,
      s, _, _, hg, hdis, n1, sc, hn, ht, hu => by
    have hcl := methodIn_closed hwf hok (Scope.dec h2) h3
    have ih := TypingSeq.gsub hwf hok hd h11 hg
      (fun X hX => hdis X (by simpa [Expr.tbindersList, Expr.tbinders] using hX))
      n1 sc (by simpa [Expr.noShadowList, Expr.noShadow] using hn)
      (by simpa [NoThis, Expr.vbindersList, Expr.vbinders] using ht)
      (by simpa [Expr.uniqList, Expr.uniq] using hu)
    have hlen : (Ts0 ++ Ts1).length = (D0.Delta ++ Delta1).length := by simp [h4, h5]
    have e6 := congrArg (Ty.substList s.ty) h6
    rw [substList_bind_comp hlen hcl.1, substList_app] at e6
    have hs1 := Sub.subst hd hg.substCtx.sub h1
    have hk8 := Kind.subst hd hg.substCtx.sub hg.substCtx.kind h8
    refine Typing.superCall hs1 h2 h3 (by rw [substList_length, h4]) (by rw [substList_length, h5]) e6 h7 hk8
      (KindSeq.substC hd hg.substCtx h9) ?_ ih
    have := SubSeq.subst hd hg.substCtx.sub h10
    rwa [substList_bind_comp hlen hcl.2, substList_app] at this
  | _, _, _, _, .newTop (D := D) h1 h2 h3 h4 h5, s, _, _, hg, hdis, n1, sc, hn, ht, hu => by
    simp only [Expr.noShadow, noShadowList_append, Bool.and_eq_true, Expr.tbinders, tbindersList_append, listMem_iff,
      List.mem_append, NoThis, Expr.vbinders, vbindersList_append, not_or, Expr.uniq,
      uniqList_append] at hn hdis ht hu
    have ih1 := TypingSeq.gsub hwf hok hd h4 hg (fun X hX => hdis X (Or.inl hX)) n1 sc hn.1 ht.1 hu.1
    have ih2 := Typing.gsub hwf hok hd h5 hg (fun X hX => hdis X (Or.inr (by simpa [Expr.tbinders] using hX))) n1 sc
      (by simpa [Expr.noShadow] using hn.2) (by simpa [NoThis, Expr.vbinders] using ht.2)
      (by simpa [Expr.uniq] using hu.2)
    rw [substList_bind_comp h3 (slots_closed hok h1)] at ih1
    simp only [Expr.gsubst] at ih2
    rw [substList_bind_comp h3 (hd.supD D h1)] at ih2
    have hk2 := Kind.subst hd hg.substCtx.sub hg.substCtx.kind h2
    simp only [Expr.gsubst, Expr.gsubstList_append, Ty.subst]
    exact Typing.newTop h1 hk2 (by rw [substList_length, h3]) ih1 ih2
  | _, Gamma, _, _, .newLocal (C := C) (Fs := Fs) (Ms := Ms) (Delta' := Dp) h1 h2 h3 h4 h5 h6 h7 h8, s, Xs, xs,
      hg, hdis, n1, sc, hn, ht, hu => by
    have hn0 := hn
    have hdis0 := hdis
    have ht0 := ht
    have hu0 := hu
    simp only [Expr.noShadow, Bool.and_eq_true, Expr.tbinders, listMem_iff, List.mem_append, NoThis, Expr.vbinders,
      not_or, Expr.uniq] at hn hdis ht hu
    have ih6 := Typing.gsub hwf hok hd h6 hg (fun X hX => hdis X (Or.inl (by simpa [Expr.tbinders] using hX))) n1 sc
      (by simpa [Expr.noShadow] using hn.1) (by simpa [NoThis, Expr.vbinders] using ht.1)
      (by simpa [Expr.uniq] using hu.1)
    refine Typing.gsub_newLocal hwf hok hd h1 h2 h3 h4 h5 h8 ih6 ?_ hg hdis0 n1 sc hn0 ht0 hu0
    intro M hM
    exact MethodOk.gsub hwf hok hd (h7 M hM) (hg.mono h2.sub)
      (fun X hX => hdis X (Or.inr (Method.mem_tbindersList hM hX))) (innerG_nodup n1 _ _) (innerG_dom sc _ _)
      (Method.noShadowList_mem hM hn.2) (fun h => ht.2 (Method.mem_vbindersList hM h)) (Method.uniqList_mem hM hu.2)
  | Delta, Gamma, _, _, .ifInstanceof (e0 := e0) (x := x) h0 hk hc h1 h2, s, _, xs, hg, hdis, n1, sc, hn, ht, hu => by
    simp only [Expr.noShadow, Bool.and_eq_true, Bool.not_eq_true', Expr.tbinders, listMem_iff, List.mem_append,
      NoThis, Expr.vbinders, List.mem_cons, not_or, Expr.uniq] at hn hdis ht hu
    have hxs : Not (List.Mem x xs) := by have := hn.1.1.2; simp at this; exact this
    have ih0 := Typing.gsub hwf hok hd h0 hg (fun X hX => hdis X (Or.inl (Or.inl hX))) n1 sc hn.1.1.1 ht.1.1.2 hu.1
    have ih1 := Typing.gsub hwf hok hd h1 (xs := x :: xs) hg (fun X hX => hdis X (Or.inl (Or.inr hX)))
      (by rw [gdom_append_single]; exact nodup_snoc n1 (fun h => hxs (sc _ h)))
      (scope_snoc sc)
      hn.1.2 ht.1.2 hu.2.1
    have ih2 := Typing.gsub hwf hok hd h2 hg (fun X hX => hdis X (Or.inr hX)) n1 sc hn.2 ht.2 hu.2.2
    simp only [gsubG, List.map_append, List.map_cons, List.map_nil, VarDecl.subst] at ih1
    rcases Cast.gsub hd hg.substCtx hc with ⟨T1, hT1⟩
    have ty0 : Typing d (gsubB s Delta) (gsubG s Gamma) (Expr.gsubst s e0) T1 := by
      rcases hT1.2.2 with e | hk1
      . rw [e]; exact ih0
      . exact Typing.subs ih0 hk1 hT1.1
    exact Typing.ifInstanceof ty0 (Kind.subst hd hg.substCtx.sub hg.substCtx.kind hk) hT1.2.1 ih1 ih2
theorem TypingSeq.gsub {d : Decls} (hwf : WFDecls d) (hok : DeclsOk d) (hd : DeclOk d) :
    forall {Delta Gamma es Ts}, TypingSeq d Delta Gamma es Ts ->
    forall {s Xs xs}, GOk d Delta s ->
    (forall X, List.Mem X (Expr.tbindersList es) -> Not (List.Mem X (s.map Prod.fst))) ->
    (gdom Gamma).Nodup -> Sub1 (gdom Gamma) xs -> Expr.noShadowList Xs xs es = true ->
    Not (List.Mem this (Expr.vbindersList es)) -> Expr.uniqList es ->
    TypingSeq d (gsubB s Delta) (gsubG s Gamma) (Expr.gsubstList s es) (Ty.substList s.ty Ts)
  | _, _, _, _, .nil, _, _, _, _, _, _, _, _, _, _ => TypingSeq.nil
  | _, _, _, _, .cons h hs, _, _, _, hg, hdis, n1, sc, hn, ht, hu => by
    simp only [Expr.noShadowList, Bool.and_eq_true, Expr.tbindersList, listMem_iff, List.mem_append,
      Expr.vbindersList, not_or, Expr.uniqList] at hn hdis ht hu
    exact TypingSeq.cons (Typing.gsub hwf hok hd h hg (fun X hX => hdis X (Or.inl hX)) n1 sc hn.1 ht.1 hu.1)
      (TypingSeq.gsub hwf hok hd hs hg (fun X hX => hdis X (Or.inr hX)) n1 sc hn.2 ht.2 hu.2)
theorem MethodOk.gsub {d : Decls} (hwf : WFDecls d) (hok : DeclsOk d) (hd : DeclOk d) :
    forall {Delta Gamma M}, MethodOk d Delta Gamma M ->
    forall {s Xs xs}, GOk d Delta s -> (forall X, List.Mem X M.tbinders -> Not (List.Mem X (s.map Prod.fst))) ->
    (gdom Gamma).Nodup -> Sub1 (gdom Gamma) (this :: xs) -> M.noShadow Xs xs = true -> NoThisM M -> M.uniq ->
    MethodOk d (gsubB s Delta) (gsubG s Gamma) (M.gsubst s)
  | _, Gamma, _, .methodOk (Delta' := Dm) (ps := ps) h1 h2 h3, s, Xs, xs, hg, hdis, n1, sc, hn, ht, hu => by
    simp only [Method.noShadow, Bool.and_eq_true, Method.tbinders, listMem_iff, List.mem_append, NoThisM,
      Method.vbinders, not_or, Method.uniq] at hn hdis ht hu
    have hdm : forall b, List.Mem b Dm -> Not (List.Mem b.X (s.map Prod.fst)) :=
      fun b hb => hdis b.X (Or.inl (List.mem_map_of_mem (f := Bound.X) hb))
    have hg2 := hg.append hdm
    have hc2 := hg2.substCtx
    rw [gsubB_append hdm] at hc2
    have hb := Typing.gsub hwf hok hd h3 (xs := this :: xs ++ ps.map VarDecl.x) hg2 (fun X hX => hdis X (Or.inr hX))
      (nodup_params n1 sc hu.2.1 ht.1 hn.1.2) (scope_params sc) hn.2 ht.2 hu.2.2
    rw [gsubB_append hdm] at hb
    simp only [gsubG, List.map_append] at hb
    refine MethodOk.methodOk ?_ ?_ hb
    . rw [cod_subst]; exact KindSeq.substC hd hc2 h1
    . have := KindSeq.substC hd hc2 h2
      rw [params_T_subst]
      exact this
end

end Funnelling
