import Funnelling.Declarations

namespace Funnelling

inductive Seq2 {A B : Type} (R : A -> B -> Prop) : List A -> List B -> Prop
  | nil : Seq2 R [] []
  | cons {a b as bs} : R a b -> Seq2 R as bs -> Seq2 R (a :: as) (b :: bs)

inductive Sub (d : Decls) (Delta : Bounds) : Ty -> Ty -> Prop
  | subRefl {T} : Sub d Delta T T
  | subInherit {D Ts0 T'} :
      Declared d (.dec D) ->
      Ts0.length = D.Delta.length ->
      Sub d Delta ((Ty.cls D.C' D.Ts).subst (bind D.Delta Ts0)) T' ->
      Sub d Delta (.cls D.C Ts0) T'
  | subInheritLocal {C Fs C' Ts' es Ms Delta0 Ts T'} :
      Declared d (.newLocal C Fs C' Ts' es Ms) ->
      Scope d C Delta0 ->
      Ts.length = Delta0.length ->
      Sub d Delta ((Ty.cls C' Ts').subst (bind Delta0 Ts)) T' ->
      Sub d Delta (.cls C Ts) T'
  | subVar {X T T'} :
      List.Mem { X := X, T := T } Delta -> Sub d Delta T T' -> Sub d Delta (.var X) T'

abbrev SubSeq (d : Decls) (Delta : Bounds) : List Ty -> List Ty -> Prop := Seq2 (Sub d Delta)

inductive Kind (d : Decls) (Delta : Bounds) : Ty -> Prop
  | kindVar {X T} : List.Mem { X := X, T := T } Delta -> Kind d Delta (.var X)
  | kindClass {C Ts Delta0} :
      Scope d C Delta0 ->
      (forall T, List.Mem T Ts -> Kind d Delta T) ->
      Ts.length = Delta0.length ->
      SubSeq d Delta Ts (Ty.substList (bind Delta0 Ts) (cod Delta0)) ->
      Kind d Delta (.cls C Ts)

abbrev KindSeq (d : Decls) (Delta : Bounds) (Ts : List Ty) : Prop := forall T, List.Mem T Ts -> Kind d Delta T

inductive Cast (d : Decls) (Delta : Bounds) : Ty -> Ty -> Prop
  | castUp {T T'} : Sub d Delta T T' -> Cast d Delta T T'
  | castVar {X T T'} :
      List.Mem { X := X, T := T } Delta -> Cast d Delta T T' -> Cast d Delta (.var X) T'
  | castDown {C Ts C' Ts0 Delta0 Ts'} :
      Sub d Delta (.cls C Ts) (.cls C' Ts0) ->
      Scope d C Delta0 ->
      Sub d [] (.cls C (vars (dom Delta0))) (.cls C' Ts') ->
      (forall X, List.Mem X (dom Delta0) -> List.Mem X (Ty.ftvList Ts')) ->
      Cast d Delta (.cls C' Ts0) (.cls C Ts)

inductive OverrideOkM (d : Decls) : Ty -> Method -> Prop
  | absent {D Ts Delta' T0' m ps' e'} :
      Declared d (.dec D) ->
      Not (List.Mem m (D.Ms.map Method.name)) ->
      OverrideOkM d (.cls D.C Ts) (.mk Delta' T0' m ps' e')
  | found {C Ts Delta0 Delta' T0' m ps' e' Delta'' T0 ps e} :
      MethodIn d (.mk Delta'' T0 m ps e) C ->
      Scope d C Delta0 ->
      Ts.length = Delta0.length -> Delta'.length = Delta''.length ->
      Ty.substList (bind (Delta0 ++ Delta'') (Ts ++ vars (dom Delta'))) (cod Delta'')
        = cod Delta' ->
      Ty.substList (bind (Delta0 ++ Delta'') (Ts ++ vars (dom Delta')))
        (T0 :: ps.map VarDecl.T) = T0' :: ps'.map VarDecl.T ->
      OverrideOkM d (.cls C Ts) (.mk Delta' T0' m ps' e')

def OverrideOk (d : Decls) (Delta : Bounds) (T : Ty) (Ms : List Method) : Prop :=
  forall M C Ts, List.Mem M Ms -> Sub d Delta T (.cls C Ts) -> OverrideOkM d (.cls C Ts) M

def Consistent (d : Decls) : ClassDecl -> Prop
  | .newLocal C Fs C' Ts _ Ms =>
    exists Fs' Ts' es' Ms' Delta0,
      Declared d (.newLocal C Fs' C' Ts' es' Ms') /\
      Scope d C Delta0 /\
      Fs.length = Delta0.length /\
      Ts = Ty.substList (bind Delta0 (abs Fs)) Ts' /\
      (forall m, List.Mem m (Ms'.map Method.name) <-> List.Mem m (Ms.map Method.name)) /\
      forall M, List.Mem M Ms -> OverrideOkM d (.cls C (abs Fs)) M
  | .dec _ => False

def restrict (Gamma : TypeEnv) (Xs : List TVarName) : TypeEnv :=
  Gamma.filter fun d => (Ty.ftv d.T).all fun X => Xs.contains X

def withoutThis (Gamma : TypeEnv) : TypeEnv := Gamma.filter fun d => d.x != this

mutual
inductive Typing (d : Decls) : Bounds -> TypeEnv -> Expr -> Ty -> Prop
  | subs {Delta Gamma e T1 T2} :
      Typing d Delta Gamma e T1 -> Kind d Delta T2 -> Sub d Delta T1 T2 ->
      Typing d Delta Gamma e T2
  | var {Delta Gamma x T} :
      Gamma.lookup x = some T -> Typing d Delta Gamma (.var x) T
  | newObject {Delta Gamma} :
      Typing d Delta Gamma (.new Object [] []) (.cls Object [])
  | field {Delta Gamma e D Ts' T f} :
      Typing d Delta Gamma e (.cls D.C Ts') ->
      Declared d (.dec D) ->
      List.Mem { T := T, f := f } D.Ss ->
      Ts'.length = D.Delta.length ->
      Typing d Delta Gamma (.field e f) (T.subst (bind D.Delta Ts'))
  | call {Delta Gamma e0 C0 Ts0 Delta0 Delta1 T0 m ps e Ts1 es T0' Ts'} :
      Typing d Delta Gamma e0 (.cls C0 Ts0) ->
      Scope d C0 Delta0 ->
      MethodIn d (.mk Delta1 T0 m ps e) C0 ->
      Ts0.length = Delta0.length -> Ts1.length = Delta1.length ->
      T0' :: Ts' = Ty.substList (bind (Delta0 ++ Delta1) (Ts0 ++ Ts1)) (T0 :: ps.map VarDecl.T) ->
      KindSeq d Delta Ts1 ->
      SubSeq d Delta Ts1 (Ty.substList (bind (Delta0 ++ Delta1) (Ts0 ++ Ts1)) (cod Delta1)) ->
      TypingSeq d Delta Gamma es Ts' ->
      Typing d Delta Gamma (.call e0 Ts1 m es) T0'
  | superCall {Delta Gamma e0 D Ts D0 Ts0 Delta1 T0 m ps e Ts1 es T0' Ts'} :
      Sub d Delta (.cls D.C Ts) (.cls D0.C Ts0) ->
      Declared d (.dec D0) ->
      MethodIn d (.mk Delta1 T0 m ps e) D0.C ->
      Ts0.length = D0.Delta.length -> Ts1.length = Delta1.length ->
      T0' :: Ts' = Ty.substList (bind (D0.Delta ++ Delta1) (Ts0 ++ Ts1)) (T0 :: ps.map VarDecl.T) ->
      Declared d (.dec D) ->
      Kind d Delta (.cls D.C Ts) ->
      KindSeq d Delta Ts1 ->
      SubSeq d Delta Ts1 (Ty.substList (bind (D0.Delta ++ Delta1) (Ts0 ++ Ts1)) (cod Delta1)) ->
      TypingSeq d Delta Gamma (e0 :: es) (.cls D.C Ts :: Ts') ->
      Typing d Delta Gamma (.superCall e0 (.cls D.C Ts) Ts1 m es) T0'
  | newTop {Delta Gamma D Ts' es1 es2 T''} :
      Declared d (.dec D) ->
      Kind d Delta (.cls D.C Ts') ->
      Ts'.length = D.Delta.length ->
      TypingSeq d Delta Gamma es1 (Ty.substList (bind D.Delta Ts') (D.Ss.map Slot.T)) ->
      Typing d Delta Gamma (.new D.C' (Ty.substList (bind D.Delta Ts') D.Ts) es2) T'' ->
      Typing d Delta Gamma (.new D.C Ts' (es1 ++ es2)) (.cls D.C Ts')
  | newLocal {Delta Gamma C Fs C' Ts es Ms Delta' T''} :
      Consistent d (.newLocal C Fs C' Ts es Ms) ->
      RestrictB Delta Fs Delta' ->
      (forall X, List.Mem X (Ty.ftvList (cod Delta')) -> List.Mem X (dom Delta')) ->
      Kind d Delta' (.cls C (abs Fs)) ->
      Kind d Delta' (.cls C' Ts) ->
      Typing d Delta Gamma (.new C' Ts es) T'' ->
      (forall M, List.Mem M Ms ->
        MethodOk d Delta'
          (withoutThis (restrict Gamma (Ty.ftvList (abs Fs))) ++ [{ T := .cls C (abs Fs), x := this }]) M) ->
      OverrideOk d Delta' (.cls C' Ts) Ms ->
      Typing d Delta Gamma (.newLocal C Fs C' Ts es Ms) (.cls C (abs Fs))
  | ifInstanceof {Delta Gamma e0 T0 T x e1 e2 T'} :
      Typing d Delta Gamma e0 T0 ->
      Kind d Delta T ->
      Cast d Delta T0 T ->
      Typing d Delta (Gamma ++ [{ T := T, x := x }]) e1 T' ->
      Typing d Delta Gamma e2 T' ->
      Typing d Delta Gamma (.ifInst e0 T x e1 e2) T'
inductive TypingSeq (d : Decls) : Bounds -> TypeEnv -> List Expr -> List Ty -> Prop
  | nil {Delta Gamma} : TypingSeq d Delta Gamma [] []
  | cons {Delta Gamma e es T Ts} :
      Typing d Delta Gamma e T -> TypingSeq d Delta Gamma es Ts ->
      TypingSeq d Delta Gamma (e :: es) (T :: Ts)
inductive MethodOk (d : Decls) : Bounds -> TypeEnv -> Method -> Prop
  | methodOk {Delta Gamma Delta' T0 m ps e} :
      KindSeq d (Delta ++ Delta') (cod Delta') ->
      KindSeq d (Delta ++ Delta') (T0 :: ps.map VarDecl.T) ->
      Typing d (Delta ++ Delta') (Gamma ++ ps) e T0 ->
      MethodOk d Delta Gamma (.mk Delta' T0 m ps e)
end

def ClassOk (d : Decls) (D : Dec) : Prop :=
  KindSeq d D.Delta (cod D.Delta) /\
  KindSeq d D.Delta (Ty.cls D.C' D.Ts :: D.Ss.map Slot.T) /\
  (forall M, List.Mem M D.Ms ->
    MethodOk d D.Delta [{ T := .cls D.C (vars (dom D.Delta)), x := this }] M) /\
  OverrideOk d D.Delta (.cls D.C' D.Ts) D.Ms

def DeclsOk (d : Decls) : Prop := forall D, List.Mem D d -> ClassOk d D

def ProgOk (d : Decls) (e : Expr) : Prop :=
  DeclsOk d /\ exists T, Typing d [] [] e T

end Funnelling
