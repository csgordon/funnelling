import Funnelling.Soundness
import Funnelling.ExampleFacts

namespace Funnelling.Examples

open Funnelling.ExampleFacts

def cn (s : String) : ClassName := { name := s }
def mn (s : String) : MethName := { name := s }
def fn (s : String) : FieldName := { name := s }
def vn (s : String) : VarName := { name := s }
def tn (s : String) : TVarName := { name := s }

def obj : Ty := .cls Object []
def tA : Ty := .cls (cn "A") []
def tB : Ty := .cls (cn "B") []
def gA : GTy := .cls (cn "A") []
def gB : GTy := .cls (cn "B") []
def vA : Value := .new (cn "A") [] []
def vB : Value := .new (cn "B") [] []
def thisE : Expr := .var this

def decObject : Dec := { C := Object, Delta := [], C' := Object, Ts := [], Ms := [], Ss := [] }
def decA : Dec := { C := cn "A", Delta := [], C' := Object, Ts := [], Ms := [], Ss := [] }
def decB : Dec :=
  { C := cn "B", Delta := [], C' := Object, Ts := [], Ms := [.mk [] tB (mn "onlyB") [] vB], Ss := [] }
def decBox : Dec :=
  { C := cn "Box", Delta := [{ X := tn "X", T := obj }], C' := Object, Ts := [],
    Ms := [.mk [] (.var (tn "X")) (mn "get") [] (.field thisE (fn "val"))],
    Ss := [{ T := .var (tn "X"), f := fn "val" }] }
def decC1 : Dec :=
  { C := cn "C1", Delta := [], C' := Object, Ts := [], Ms := [.mk [] tA (mn "m") [] vA], Ss := [] }
def decC2 : Dec := { C := cn "C2", Delta := [], C' := cn "C1", Ts := [], Ms := [], Ss := [] }

def d1 : Decls := [decObject, decA, decB, decBox, decC1, decC2]

-- W1: the class table d1 is well formed.
theorem w1 : WFDecls d1 := by decide

-- W2: a method declaring two parameters named x violates A4.
def decDup : Dec :=
  { C := cn "Dup", Delta := [], C' := Object, Ts := [],
    Ms := [.mk [] tA (mn "m") [{ T := tA, x := vn "x" }, { T := tA, x := vn "x" }] (.var (vn "x"))],
    Ss := [] }
theorem w2 : Not (A4 (Decls.methods [decObject, decA, decDup])) := by decide

-- W3: an if binding the parameter x again violates A7.
def decShadow : Dec :=
  { C := cn "Shadow", Delta := [], C' := Object, Ts := [],
    Ms := [.mk [] tA (mn "m") [{ T := tA, x := vn "x" }]
      (.ifInst (.var (vn "x")) tA (vn "x") (.var (vn "x")) (.var (vn "x")))],
    Ss := [] }
theorem w3 : Not (A7Decls [decObject, decA, decShadow]) := by decide

-- W4: a superclass that is not declared violates A9 and A10.
def decOrphan : Dec := { C := cn "Orphan", Delta := [], C' := cn "Missing", Ts := [], Ms := [], Ss := [] }
theorem w4 : Not (A9 [decObject, decOrphan]) /\ Not (A10 [decObject, decOrphan]) := by decide

-- R1: rule topFieldFound.
theorem r1 : Reduces d1 (.field (Value.new (cn "Box") [gA] [vA]) (fn "val")) vA :=
  And.intro
    (Step.topFieldFound (D := decBox) (vs1 := [vA]) (vs := [])
      (.dec (.tail _ (.tail _ (.tail _ (.head _))))) rfl (.head _))
    (by decide)

-- R2: rule topAddSuper.
theorem r2 : Reduces d1 (.call (Value.new (cn "C2") [] []) [] (mn "m") [])
    (.superCall (Value.new (cn "C2") [] []) (.cls (cn "C2") []) [] (mn "m") []) :=
  And.intro (Step.topAddSuper (Gs' := []) (vs := []) rfl) (by decide)

-- R3: rule searchSuper.
theorem r3 : Reduces d1 (.superCall (Value.new (cn "C2") [] []) (.cls (cn "C2") []) [] (mn "m") [])
    (.superCall (Value.new (cn "C2") [] []) (.cls (cn "C1") []) [] (mn "m") []) :=
  And.intro
    (Step.searchSuper (D := decC2) (Gs := []) (Gs' := []) (vs := [])
      (.dec (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (by intro h; cases h)
      (by decide) rfl)
    (by decide)

-- R4: rule topFound, with no names to rename.
theorem r4 : Reduces d1 (.superCall (Value.new (cn "C2") [] []) (.cls (cn "C1") []) [] (mn "m") []) vA :=
  And.intro
    (Step.topFound (D := decC1) (M := .mk [] tA (mn "m") [] vA) (Gs := []) (Gs' := []) (vs := [])
      (Delta' := []) (T0 := tA) (ps := []) (e0 := vA)
      (.dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))) (.head _)
      (And.intro (.mk (Xs' := []) (xs' := []) rfl rfl (.new .nil)) (.mk (Xs' := []) (xs' := []) rfl rfl (.new .nil))) rfl rfl (by decide) (by decide) rfl (by decide) (by decide) rfl)
    (by decide)

-- R5: rule ctx, inside the receiver of a call.
theorem r5 : Reduces d1 (.call (.field (Value.new (cn "Box") [gA] [vA]) (fn "val")) [] (mn "m") [])
    (.call vA [] (mn "m") []) :=
  And.intro
    (Step.ctx (E := .callRecv .hole [] (mn "m") [])
      (Step.topFieldFound (D := decBox) (vs1 := [vA]) (vs := [])
        (.dec (.tail _ (.tail _ (.tail _ (.head _))))) rfl (.head _)))
    (by decide)

-- R6: rules ifThen and ifElse.
theorem r6Then : Reduces d1 (.ifInst vA tA (vn "x") (.var (vn "x")) vB) vA :=
  And.intro
    (Step.ifThen (v := vA) (C' := cn "A") (Ts := []) (Ts' := []) (x := vn "x") (e1 := .var (vn "x"))
      (e1' := .var (vn "x")) (e2 := vB) .subRefl (And.intro .var .var) (by decide))
    (by decide)

-- R11: three steps, new C2<>().m() reduces to new A<>().
theorem r11 : ReducesStar d1 (.call (Value.new (cn "C2") [] []) [] (mn "m") []) vA :=
  ReducesStar.step r2 (ReducesStar.step r3 (ReducesStar.step r4 ReducesStar.refl))

def tFoo (T : Ty) : Ty := .cls (cn "Foo") [T]
def decFoo : Dec :=
  { C := cn "Foo", Delta := [{ X := tn "X", T := obj }], C' := Object, Ts := [],
    Ms := [.mk [] (.var (tn "X")) (mn "x") [] (.call thisE [] (mn "x") [])], Ss := [] }
def myFooMethod : Method := .mk [] (.var (tn "Y")) (mn "x") [] (.var (vn "y"))
def myFooBody : Expr := .newLocal (cn "MyFoo") [.funnel (tn "Y")] (cn "Foo") [.var (tn "Y")] [] [myFooMethod]
def mkMethod : Method :=
  .mk [{ X := tn "Y", T := obj }] (tFoo (.var (tn "Y"))) (mn "mk") [{ T := .var (tn "Y"), x := vn "y" }] myFooBody
theorem kFooG {d : Decls} (hFoo : List.Mem decFoo d) {Delta : Bounds} {T : Ty} (hk : Kind d Delta T)
    (hs : Sub d Delta T obj) : Kind d Delta (tFoo T) :=
  Kind.kindClass (Delta0 := decFoo.Delta) (Scope.dec (.dec hFoo))
    (by intro T' h; cases h with | head => exact hk | tail _ h => cases h) rfl (.cons hs .nil)

theorem overFooG {d : Decls} (hwf : WFDecls d) (hN : Closed d [Object]) (hO : ObjArgs d)
    (hObj : List.Mem decObject d) (hFoo : List.Mem decFoo d) {Delta : Bounds} {T : Ty} {e : Expr} :
    OverrideOk d Delta (tFoo T) [.mk [] T (mn "x") [] e] := by
  intro M C Ts hM hs
  cases hM with
  | tail _ h => cases h
  | head =>
  cases Sub.dec_step hwf (D := decFoo) (.dec hFoo) hs with
  | inl e =>
    rw [e]
    exact OverrideOkM.found (Delta'' := []) (T0 := .var (tn "X")) (ps := []) (e := .call thisE [] (mn "x") [])
      ⟨.dec decFoo, .dec hFoo, rfl, .head _⟩ (Scope.dec (D := decFoo) (.dec hFoo)) rfl rfl rfl rfl
  | inr h2 => exact overObj hN hO hObj rfl rfl h2.2

def decMaker : Dec := { C := cn "Maker", Delta := [], C' := Object, Ts := [], Ms := [mkMethod], Ss := [] }

def d2 : Decls := [decObject, decA, decB, decFoo, decMaker]

-- W5: the class table d2, with the funnelled local class MyFoo, is well formed.
theorem w5 : WFDecls d2 := by decide

def vLocal : Value := .newLocal (cn "MyFoo") [gA] (cn "Foo") [gA] [] [.mk [] tA (mn "x") [] vA]

-- R7: rule topFound renames Y and y into Y1 and y1, then replaces Y1 and y1.
theorem r7 : Reduces d2
    (.superCall (Value.new (cn "Maker") [] []) (.cls (cn "Maker") []) [tA] (mn "mk") [vA]) vLocal :=
  And.intro
    (Step.topFound (D := decMaker) (M := mkMethod) (Gs := []) (Gs' := [gA]) (vs := [vA])
      (Delta' := [{ X := tn "Y1", T := obj }]) (T0 := tFoo (.var (tn "Y1")))
      (ps := [{ T := .var (tn "Y1"), x := vn "y1" }])
      (e0 := .newLocal (cn "MyFoo") [.funnel (tn "Y1")] (cn "Foo") [.var (tn "Y1")] []
        [.mk [] (.var (tn "Y1")) (mn "x") [] (.var (vn "y1"))])
      (.dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))) (.head _)
      (And.intro
        (.mk (Xs' := [tn "Y1"]) (xs' := [vn "y1"]) rfl rfl
          (.newLocal .nil (.cons (.mk (Xs' := []) (xs' := []) rfl rfl .var) .nil)))
        (.mk (Xs' := [tn "Y"]) (xs' := [vn "y"]) rfl rfl
          (.newLocal .nil (.cons (.mk (Xs' := []) (xs' := []) rfl rfl .var) .nil))))
      rfl rfl (by decide) (by decide) rfl (by decide) (by decide) rfl)
    (by decide)

-- R8: rule localFound.
theorem r8 : Reduces d2 (.call vLocal [] (mn "x") []) vA :=
  And.intro
    (Step.localFound (v0 := vLocal) (M := .mk [] tA (mn "x") [] vA) (Gs' := []) (vs := [])
      (Delta' := []) (T0 := tA) (ps := []) (e0 := vA) rfl (.head _)
      (And.intro (.mk (Xs' := []) (xs' := []) rfl rfl (.new .nil)) (.mk (Xs' := []) (xs' := []) rfl rfl (.new .nil))) rfl rfl (by decide) (by decide) (by decide) (by decide) rfl)
    (by decide)

-- R9: rule localSuper.
theorem r9 : Reduces d2 (.call vLocal [] (mn "other") [])
    (.superCall vLocal (tFoo tA) [] (mn "other") []) :=
  And.intro
    (Step.localSuper (v0 := vLocal) (Gs' := []) (vs := []) rfl (by decide))
    (by decide)

-- R10: rule localFieldSuper.
theorem r10 : Reduces d2 (.field vLocal (fn "f")) (.field (Value.new (cn "Foo") [gA] []) (fn "f")) :=
  And.intro Step.localFieldSuper (by decide)

-- T1: new Box<A<>>(new A<>()).val has type A<>.
theorem kindA : Kind d1 [] tA :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decA) (.dec (.tail _ (.head _))))
    (by intro T h; cases h) rfl .nil

theorem subAObj : Sub d1 [] tA obj :=
  Sub.subInherit (D := decA) (.dec (.tail _ (.head _))) rfl .subRefl

theorem kindBoxA : Kind d1 [] (.cls (cn "Box") [tA]) :=
  Kind.kindClass (Delta0 := decBox.Delta)
    (Scope.dec (D := decBox) (.dec (.tail _ (.tail _ (.tail _ (.head _))))))
    (by intro T h; cases h with
      | head => exact kindA
      | tail _ h => cases h)
    rfl (.cons subAObj .nil)

theorem typA : Typing d1 [] [] vA tA :=
  Typing.newTop (D := decA) (es1 := []) (es2 := []) (.dec (.tail _ (.head _))) kindA rfl .nil
    Typing.newObject

theorem typBox : Typing d1 [] [] (Value.new (cn "Box") [gA] [vA]) (.cls (cn "Box") [tA]) :=
  Typing.newTop (D := decBox) (es1 := [vA]) (es2 := [])
    (.dec (.tail _ (.tail _ (.tail _ (.head _))))) kindBoxA rfl (.cons typA .nil) Typing.newObject

theorem t1 : Typing d1 [] [] (.field (Value.new (cn "Box") [gA] [vA]) (fn "val")) tA :=
  Typing.field (D := decBox) (T := .var (tn "X")) typBox
    (.dec (.tail _ (.tail _ (.tail _ (.head _))))) (.head _) rfl

-- T2: new Box<A<>>(new B<>()) is ill typed: B<> is not a subtype of A<>.
theorem t2 : Not (exists T, Typing d1 [] [] (Value.new (cn "Box") [gA] [vB]) T) := by
  intro h
  cases h with
  | intro T h =>
    cases inv_new h rfl with
    | inl h1 => exact absurd h1.1 (by decide)
    | inr h1 =>
      cases h1 with
      | intro w hw =>
        cases w with
        | mk D es1 es2 T'' =>
          have hn : D.C = decBox.C := hw.name
          have e : D = decBox := dec_unique w1 hn hw.decl (.dec (.tail _ (.tail _ (.tail _ (.head _)))))
          subst e
          have hf : TypingSeq d1 [] [] es1 [tA] := hw.fields
          have hs : [vB.expr] = es1 ++ es2 := hw.split
          cases hf with
          | cons h2 h3 =>
            cases h3
            simp only [List.cons_append, List.nil_append, List.cons.injEq] at hs
            rw [<- hs.1] at h2
            cases (value_typing w1 h2).1 with
            | inl e =>
              injection e with e
              exact absurd e (by decide)
            | inr h4 => exact notSub [cn "B", Object] (by decide) (.head _) (by decide) h4.1

def myFooK : ClassDecl := .newLocal (cn "MyFoo") [.funnel (tn "Y")] (cn "Foo") [.var (tn "Y")] [] [myFooMethod]

theorem myFooDeclared : Declared d2 myFooK :=
  Declared.newLocal (K := .dec decMaker) (.dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))
    (.head _) (Exists.intro .hole rfl)

theorem scopeMyFoo : Scope d2 (cn "MyFoo") [{ X := tn "Y", T := obj }] :=
  Scope.newLocal (C := cn "Maker") (Delta' := [{ X := tn "Y", T := obj }]) (T0 := tFoo (.var (tn "Y"))) (m := mn "mk")
    (ps := [{ T := .var (tn "Y"), x := vn "y" }]) (e := myFooBody) (Delta := [])
    ⟨.dec decMaker, .dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))), rfl, .head _⟩ ⟨.hole, rfl⟩
    (Scope.dec (D := decMaker) (.dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (RestrictB.funnel (.head _) .nil)

-- C1: rule cast-down accepts the type test instanceof MyFoo<X> from Foo<X>.
theorem c1 : Cast d2 [{ X := tn "X", T := obj }] (tFoo (.var (tn "X"))) (.cls (cn "MyFoo") [.var (tn "X")]) :=
  Cast.castDown (Ts' := [.var (tn "Y")])
    (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)
    scopeMyFoo
    (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)
    (by intro X h; cases h with
      | head => exact .head _
      | tail _ h => cases h)

-- C2: rule cast-down rejects the type test instanceof MyFoo<X> from Object<>.
theorem c2 : Not (Cast d2 [{ X := tn "X", T := obj }] obj (.cls (cn "MyFoo") [.var (tn "X")])) :=
  castObj (by decide) (by decide) (by decide) (by decide)

def brokenBody : Expr :=
  .ifInst (.var (vn "other")) (.cls (cn "MyFoo") []) (vn "w") (.var (vn "w"))
    (.newLocal (cn "MyFoo") [] (cn "Foo") [.var (tn "X")] [] [.mk [] (.var (tn "X")) (mn "x") [] (.var (vn "x"))])
def decBroken : Dec :=
  { C := cn "Broken", Delta := [], C' := Object, Ts := [],
    Ms := [.mk [{ X := tn "X", T := obj }] (tFoo (.var (tn "X"))) (mn "m")
      [{ T := obj, x := vn "other" }, { T := .var (tn "X"), x := vn "x" }] brokenBody],
    Ss := [] }

def d3 : Decls := [decObject, decA, decB, decFoo, decBroken]

def eA : Expr := .call (Value.new (cn "Broken") [] []) [tA] (mn "m") [Value.new (cn "Foo") [gA] [], vA]
def brokenMain : Expr :=
  .call (.call (.call (Value.new (cn "Broken") [] []) [tB] (mn "m") [eA, vB]) [] (mn "x") []) [] (mn "onlyB") []

def Stuck (d : Decls) (e : Expr) : Prop := Not (IsValue e) /\ forall e', Not (Reduces d e e')
def stuckB : Expr := .superCall vA obj [] (mn "onlyB") []

-- W6: Example 1 in the core language is well formed.
theorem w6 : WFDecls d3 /\ WFExpr brokenMain := by decide

-- J1: Example 1 reduces to new A<>().onlyB(), then to new A<>().[Object<>]onlyB(), which is stuck.
theorem j1 : ReducesStar d3 brokenMain stuckB /\ Stuck d3 stuckB :=
  And.intro
    (ReducesStar.step (red (cRecv (cRecv (cArg0 (sAdd rfl rfl rfl rfl) rfl rfl) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (cArg0 (sFound (D := decBroken) (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))
      (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (cArg0 (sElse rfl (noSubEx [cn "Foo", Object] (by decide) (.head _) (by decide)))
      rfl rfl) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (sAdd rfl rfl rfl rfl) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (sFound (D := decBroken) (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))
      (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (sThen rfl .subRefl (by decide)) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (sInner (.head _) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sSearch (D := decA) (.tail _ (.head _)) (by decide) (by decide) rfl rfl rfl rfl rfl) (by decide))
      ReducesStar.refl)))))))))
    (stuckS (by decide))

-- N1: Example 1 is not Ok.
theorem n1 : Not (ProgOk d3 brokenMain) := fun h =>
  h.2.elim fun _ ht => (typeSoundness w6.1 h.1 w6.2 ht j1.1).2.elim j1.2.1 fun h' => h'.elim j1.2.2

def decLeaker : Dec :=
  { C := cn "Broken", Delta := [], C' := Object, Ts := [],
    Ms := [
      .mk [{ X := tn "Y", T := obj }] (.cls (cn "MyFoo2") []) (mn "mk2") [{ T := .var (tn "Y"), x := vn "y" }]
        (.newLocal (cn "MyFoo2") [] (cn "Foo") [.var (tn "Y")] [] [.mk [] (.var (tn "Y")) (mn "x") [] (.var (vn "y"))]),
      .mk [{ X := tn "Y", T := obj }] (tFoo (.var (tn "Y"))) (mn "leak") [{ T := .cls (cn "MyFoo2") [], x := vn "z" }]
        (.var (vn "z"))],
    Ss := [] }

def d4 : Decls := [decObject, decA, decB, decFoo, decLeaker]

-- W7: the class table d4 is well formed.
theorem w7 : WFDecls d4 := by decide


-- L1: the class Broken of d4 is not Ok.
theorem l1 : Not (ClassOk d4 decLeaker) := by
  intro h
  have hm := h.2.2.1 _ (.head _)
  cases hm with
  | methodOk _ _ ht =>
    cases inv_local ht rfl with
    | intro w hw =>
      have hp := hw.restr
      have hk := hw.kindS
      generalize w.Delta' = D' at hp hk
      cases hp
      cases hk with
      | kindClass _ hall _ _ =>
        have hY : Kind d4 [] (.var (tn "Y")) := hall _ (.head _)
        cases hY with
        | kindVar hm => cases hm

def meth (Delta : Bounds) (T0 : Ty) (m : String) (ps : List VarDecl) (e : Expr) : Method := .mk Delta T0 (mn m) ps e
def par (T : Ty) (x : String) : VarDecl := { T := T, x := vn x }
def bnd (X : String) (T : Ty) : Bound := { X := tn X, T := T }
def ev (x : String) : Expr := .var (vn x)
def tv (X : String) : Ty := .var (tn X)
def call0 (e : Expr) (m : String) (es : List Expr) : Expr := .call e [] (mn m) es
def onlyBCall (e : Expr) : Expr := call0 e "onlyB" []

-- Example 1, funnelled as in Section 3.

def decFixed : Dec :=
  { C := cn "Broken", Delta := [], C' := Object, Ts := [],
    Ms := [meth [bnd "X" obj] (tFoo (tv "X")) "m" [par (tFoo (tv "X")) "other", par (tv "X") "x"]
      (.ifInst (ev "other") (.cls (cn "MyFoo") [tv "X"]) (vn "w") (ev "w")
        (.newLocal (cn "MyFoo") [.funnel (tn "X")] (cn "Foo") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]))],
    Ss := [] }

def d5 : Decls := [decObject, decA, decB, decFoo, decFixed]

def vMyFooA : Value := .newLocal (cn "MyFoo") [gA] (cn "Foo") [gA] [] [meth [] tA "x" [] vA]

def fixedCallA : Expr := .call (Value.new (cn "Broken") [] []) [tA] (mn "m") [Value.new (cn "Foo") [gA] [], vA]

-- W8: the funnelled Example 1 is well formed.
theorem w8 : WFDecls d5 := by decide

theorem mF5 : List.Mem decFixed d5 := (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))
theorem mFoo5 : List.Mem decFoo d5 := (.tail _ (.tail _ (.tail _ (.head _))))
theorem mA5 : List.Mem decA d5 := (.tail _ (.head _))

theorem myFoo5 : Declared d5
    (.newLocal (cn "MyFoo") [.funnel (tn "X")] (cn "Foo") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]) :=
  Declared.newLocal (K := .dec decFixed) (.dec mF5) (.head _)
    (Exists.intro (.ifElse (ev "other") (.cls (cn "MyFoo") [tv "X"]) (vn "w") (ev "w") .hole) rfl)

theorem kX5 : Kind d5 [bnd "X" obj] (tv "X") := Kind.kindVar (.head _)
theorem sX5 : Sub d5 [bnd "X" obj] (tv "X") obj := Sub.subVar (.head _) .subRefl
theorem kFooX5 : Kind d5 [bnd "X" obj] (tFoo (tv "X")) := kFooG mFoo5 kX5 sX5

theorem scopeMyFoo5 : Scope d5 (cn "MyFoo") [bnd "X" obj] :=
  Scope.newLocal (C := cn "Broken") (Delta := [])
    (Exists.intro (.dec decFixed) (And.intro (.dec mF5) (And.intro rfl (.head _))))
    (Exists.intro (.ifElse (ev "other") (.cls (cn "MyFoo") [tv "X"]) (vn "w") (ev "w") .hole) rfl)
    (Scope.dec (.dec mF5)) (RestrictB.funnel (.head _) .nil)

theorem kMyFooX5 : Kind d5 [bnd "X" obj] (.cls (cn "MyFoo") [tv "X"]) :=
  Kind.kindClass scopeMyFoo5
    (by intro T h; cases h with | head => exact kX5 | tail _ h => cases h) rfl (.cons sX5 .nil)

theorem castX5 : Cast d5 [bnd "X" obj] (tFoo (tv "X")) (.cls (cn "MyFoo") [tv "X"]) :=
  Cast.castDown (Ts' := [tv "X"]) (Sub.subInheritLocal myFoo5 scopeMyFoo5 rfl .subRefl) scopeMyFoo5
    (Sub.subInheritLocal myFoo5 scopeMyFoo5 rfl .subRefl)
    (by intro X h; cases h with | head => exact .head _ | tail _ h => cases h)

theorem consMyFoo5 : Consistent d5
    (.newLocal (cn "MyFoo") [.funnel (tn "X")] (cn "Foo") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]) :=
  ⟨_, _, _, _, _, myFoo5, scopeMyFoo5, rfl, rfl, fun _ => Iff.rfl, by
    intro M h
    cases h with
    | head =>
      exact OverrideOkM.found (Delta'' := []) (T0 := tv "X") (ps := []) (e := ev "x") ⟨_, myFoo5, rfl, .head _⟩
        scopeMyFoo5 rfl rfl rfl rfl
    | tail _ h => cases h⟩

-- P1: the class Broken of d5 is Ok.
theorem p1 : ClassOk d5 decFixed :=
  And.intro (by intro T h; cases h)
  (And.intro (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h)
  (And.intro (by
      intro M h
      cases h with
      | tail _ h => cases h
      | head =>
      exact MethodOk.methodOk (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h) (by intro T h; cases h with | head => exact kFooX5 | tail _ h => cases h with | head => exact kFooX5 | tail _ h => cases h with | head => exact kX5 | tail _ h => cases h)
        (Typing.ifInstanceof (Typing.var rfl) kMyFooX5 castX5
          (Typing.subs (Typing.var rfl) kFooX5 (Sub.subInheritLocal myFoo5 scopeMyFoo5 rfl .subRefl))
          (Typing.subs
            (Typing.newLocal (Delta' := [bnd "X" obj]) consMyFoo5 (RestrictB.funnel (.head _) .nil)
              (by intro X h; cases h) kMyFooX5 kFooX5
              (Typing.newTop (D := decFoo) (es1 := []) (es2 := []) (.dec mFoo5) kFooX5 rfl .nil Typing.newObject)
              (by
                intro M h
                cases h with
                | head => exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; cases h with | head => exact kX5 | tail _ h => cases h) (Typing.var rfl)
                | tail _ h => cases h)
              (overFooG w8 (by decide) (by decide) (.head _) mFoo5))
            kFooX5 (Sub.subInheritLocal myFoo5 scopeMyFoo5 rfl .subRefl))))
    (overrideObj (by decide) (by decide) (D0 := decObject) (.head _) rfl rfl)))

-- T3: new Broken<>().<A<>>m(new Foo<A<>>(), new A<>()) has type Foo<A<>>.
theorem t3 : Typing d5 [] [] fixedCallA (tFoo tA) :=
  Typing.call (Delta0 := []) (Delta1 := [bnd "X" obj]) (T0 := tFoo (tv "X"))
    (ps := [par (tFoo (tv "X")) "other", par (tv "X") "x"]) (Ts' := [tFoo tA, tA])
    (Typing.newTop (D := decFixed) (es1 := []) (es2 := []) (.dec mF5) (kNull mF5 rfl) rfl .nil Typing.newObject)
    (Scope.dec (.dec mF5))
    (Exists.intro (.dec decFixed) (And.intro (.dec mF5) (And.intro rfl (.head _)))) rfl rfl rfl
    (by intro T h; cases h with | head => exact (kNull mA5 rfl) | tail _ h => cases h)
    (.cons (Sub.subInherit (D := decA) (.dec mA5) rfl .subRefl) .nil)
    (.cons (Typing.newTop (D := decFoo) (es1 := []) (es2 := []) (.dec mFoo5)
        (kFooG mFoo5 (kNull mA5 rfl) (Sub.subInherit (D := decA) (.dec mA5) rfl .subRefl)) rfl .nil Typing.newObject)
      (.cons (Typing.newTop (D := decA) (es1 := []) (es2 := []) (.dec mA5) (kNull mA5 rfl) rfl .nil Typing.newObject)
        .nil))

-- R12: that call reduces to a MyFoo<A<>> whose method x returns new A<>().
theorem r12 : ReducesStar d5 fixedCallA vMyFooA :=
  ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
  (ReducesStar.step (red (sFound (D := decFixed) (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide))
    (by decide))
  (ReducesStar.step (red (sElse rfl (noSubEx [cn "Foo", Object] (by decide) (.head _) (by decide))) (by decide))
    ReducesStar.refl))

-- R13: given a MyFoo<A<>>, the type test succeeds and mk returns it.
theorem r13 : ReducesStar d5 (.call (Value.new (cn "Broken") [] []) [tA] (mn "m") [vMyFooA, vA]) vMyFooA :=
  ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
  (ReducesStar.step (red (sFound (D := decFixed) (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide))
    (by decide))
  (ReducesStar.step (red (sThen rfl .subRefl (by decide)) (by decide))
    ReducesStar.refl))

theorem fixedMk {T R : Ty} {es : List Expr}
    (h : Typing d5 [] [] (.call (Value.new (cn "Broken") [] []) [T] (mn "m") es) R) :
    TypingSeq d5 [] [] es [tFoo T, T] /\ Up d5 [] (tFoo T) R := by
  cases inv_callTop w8 (D := decFixed) (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))) rfl rfl rfl (by decide)
    (by decide) h with
  | intro Delta1 h =>
  cases h with
  | intro T0 h =>
  cases h with
  | intro ps h =>
  cases h with
  | intro body h =>
  cases h with
  | intro T0' h =>
  cases h with
  | intro Ts' h =>
  cases h.1 with
  | tail _ h1 => cases h1
  | head =>
  have hs := h.2.2.1
  injection hs with e1 e2
  subst e1 e2
  exact And.intro h.2.2.2.1 h.2.2.2.2

-- N2: the main expression of Example 1, with the funnelled m, is ill typed: a Foo<A<>> is passed where a Foo<B<>> is expected.
theorem n2 : Not (exists T, Typing d5 [] []
    (call0 (call0 (.call (Value.new (cn "Broken") [] []) [tB] (mn "m") [fixedCallA, vB]) "x" []) "onlyB" []) T) := by
  intro h
  cases h with
  | intro T h =>
  cases inv_call h rfl with
  | intro w1 hw1 =>
  cases inv_call hw1.ty0 rfl with
  | intro w2 hw2 =>
  cases (fixedMk hw2.ty0).1 with
  | cons ha _ =>
  cases (fixedMk ha).2 with
  | inl e =>
    injection e with _ e
    injection e with e
    injection e with e
    exact absurd e (by decide)
  | inr h2 =>
    cases Sub.dec_step w8 (D := decFoo) (.dec (.tail _ (.tail _ (.tail _ (.head _))))) h2.1 with
    | inl e =>
      injection e with _ e
      injection e with e
      injection e with e
      exact absurd e (by decide)
    | inr h3 => exact notSub [Object] (by decide) (.head _) (by decide) h3.2

-- Example 2: no generic supertype; the lambdas of the paper are subclasses of Fun.

def tFun (X Y : Ty) : Ty := .cls (cn "Fun") [X, Y]
def decFun : Dec :=
  { C := cn "Fun", Delta := [bnd "X" obj, bnd "Y" obj], C' := Object, Ts := [],
    Ms := [meth [] (tv "Y") "apply" [par (tv "X") "x"] (call0 thisE "apply" [ev "x"])], Ss := [] }
def decAToB : Dec :=
  { C := cn "AToB", Delta := [], C' := cn "Fun", Ts := [tA, tB],
    Ms := [meth [] tB "apply" [par tA "a"] vB], Ss := [] }
def decAsB : Dec :=
  { C := cn "AsB", Delta := [], C' := cn "Fun", Ts := [tB, tB],
    Ms := [meth [] tB "apply" [par tB "b"] (onlyBCall (ev "b"))], Ss := [] }
def vAToB : Value := .new (cn "AToB") [] []
def vAsB : Value := .new (cn "AsB") [] []

def decBroken2 : Dec :=
  { C := cn "Broken2", Delta := [], C' := Object, Ts := [],
    Ms := [meth [bnd "X" obj] obj "m" [par obj "other", par (tv "X") "x", par (tFun (tv "X") tB) "f"]
      (.ifInst (ev "other") (.cls (cn "MyFoo2") []) (vn "local") (call0 (ev "f") "apply" [call0 (ev "local") "x" []])
        (.newLocal (cn "MyFoo2") [] Object [] [] [meth [] (tv "X") "x" [] (ev "x")]))],
    Ss := [] }

def d6 : Decls := [decObject, decA, decB, decFun, decAToB, decAsB, decBroken2]

def main2 : Expr :=
  .call (Value.new (cn "Broken2") [] []) [tB] (mn "m")
    [.call (Value.new (cn "Broken2") [] []) [tA] (mn "m") [vA, vA, vAToB], vB, vAsB]

-- W9: Example 2 in the core language is well formed.
theorem w9 : WFDecls d6 /\ WFExpr main2 := by decide

theorem r14p : ReducesStar d6 main2 stuckB /\ Stuck d6 stuckB :=
  And.intro
    (ReducesStar.step (red (cArg0 (sAdd rfl rfl rfl rfl) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sFound (D := decBroken2) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))))
      (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sElse rfl (noSubEx [cn "A", Object] (by decide) (.head _) (by decide))) rfl rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sFound (D := decBroken2) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))))
      (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (sThen rfl .subRefl (by decide)) (by decide))
    (ReducesStar.step (red (cArg0 (sInner (.head _) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sFound (D := decAsB) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))
      (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sSearch (D := decA) (.tail _ (.head _)) (by decide) (by decide) rfl rfl rfl rfl rfl) (by decide))
      ReducesStar.refl)))))))))))
    (stuckS (by decide))

-- N3: Example 2 is not Ok: the method x of MyFoo2 returns X, which MyFoo2 does not funnel.
theorem n3 : Not (ProgOk d6 main2) := fun h =>
  h.2.elim fun _ ht => (typeSoundness w9.1 h.1 w9.2 ht r14p.1).2.elim r14p.2.1 fun h' => h'.elim r14p.2.2

-- R14: Example 2 reduces to new A<>().[Object<>]onlyB(), which is stuck: AsB uses an A<> as a B<>.
theorem r14 : ReducesStar d6 main2 stuckB /\ Stuck d6 stuckB := r14p

def decHolder : Dec := { C := cn "Holder", Delta := [bnd "X" obj], C' := Object, Ts := [], Ms := [], Ss := [] }
def decFixed2 : Dec :=
  { C := cn "Fixed2", Delta := [], C' := Object, Ts := [],
    Ms := [meth [bnd "X" obj] obj "m" [par (.cls (cn "Holder") [tv "X"]) "other", par (tv "X") "x", par (tFun (tv "X") tB) "f"]
      (.ifInst (ev "other") (.cls (cn "MyFoo3") [tv "X"]) (vn "local") (call0 (ev "f") "apply" [call0 (ev "local") "x" []])
        (.newLocal (cn "MyFoo3") [.funnel (tn "X")] (cn "Holder") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]))],
    Ss := [] }
def decFixed2Obj : Dec :=
  { C := cn "Fixed2Obj", Delta := [], C' := Object, Ts := [],
    Ms := [meth [bnd "X" obj] obj "m" [par obj "other", par (tv "X") "x", par (tFun (tv "X") tB) "f"]
      (.ifInst (ev "other") (.cls (cn "MyFoo4") [tv "X"]) (vn "local") (call0 (ev "f") "apply" [call0 (ev "local") "x" []])
        (.newLocal (cn "MyFoo4") [.funnel (tn "X")] Object [] [] [meth [] (tv "X") "x" [] (ev "x")]))],
    Ss := [] }

def d6F : Decls := [decObject, decA, decB, decFun, decAToB, decAsB, decHolder, decFixed2, decFixed2Obj]

-- W10: the funnelled versions of Example 2 are well formed.
theorem w10 : WFDecls d6F := by decide

theorem mFx2 : List.Mem decFixed2 d6F := (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))))
theorem mH6 : List.Mem decHolder d6F := (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))))
theorem mFun6 : List.Mem decFun d6F := (.tail _ (.tail _ (.tail _ (.head _))))
theorem mB6 : List.Mem decB d6F := (.tail _ (.tail _ (.head _)))

theorem myFoo3D : Declared d6F
    (.newLocal (cn "MyFoo3") [.funnel (tn "X")] (cn "Holder") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]) :=
  Declared.newLocal (K := .dec decFixed2) (.dec mFx2) (.head _)
    (Exists.intro (.ifElse (ev "other") (.cls (cn "MyFoo3") [tv "X"]) (vn "local")
      (call0 (ev "f") "apply" [call0 (ev "local") "x" []]) .hole) rfl)

theorem kX6 : Kind d6F [bnd "X" obj] (tv "X") := Kind.kindVar (.head _)
theorem sX6 : Sub d6F [bnd "X" obj] (tv "X") obj := Sub.subVar (.head _) .subRefl
theorem sB6 : Sub d6F [bnd "X" obj] tB obj := Sub.subInherit (D := decB) (.dec mB6) rfl .subRefl

theorem kHolderX : Kind d6F [bnd "X" obj] (.cls (cn "Holder") [tv "X"]) :=
  Kind.kindClass (Delta0 := decHolder.Delta) (Scope.dec (.dec mH6)) (by intro T h; cases h with | head => exact kX6 | tail _ h => cases h)
    rfl (.cons sX6 .nil)

theorem kFunXB : Kind d6F [bnd "X" obj] (tFun (tv "X") tB) :=
  Kind.kindClass (Delta0 := decFun.Delta) (Scope.dec (.dec mFun6))
    (by intro T h; cases h with | head => exact kX6 | tail _ h => cases h with | head => exact (kNull mB6 rfl) | tail _ h => cases h) rfl (.cons sX6 (.cons sB6 .nil))

theorem scopeMyFoo3 : Scope d6F (cn "MyFoo3") [bnd "X" obj] :=
  Scope.newLocal (C := cn "Fixed2") (Delta := [])
    (Exists.intro (.dec decFixed2) (And.intro (.dec mFx2) (And.intro rfl (.head _))))
    (Exists.intro (.ifElse (ev "other") (.cls (cn "MyFoo3") [tv "X"]) (vn "local")
      (call0 (ev "f") "apply" [call0 (ev "local") "x" []]) .hole) rfl)
    (Scope.dec (.dec mFx2)) (RestrictB.funnel (.head _) .nil)

theorem kMyFoo3X : Kind d6F [bnd "X" obj] (.cls (cn "MyFoo3") [tv "X"]) :=
  Kind.kindClass scopeMyFoo3 (by intro T h; cases h with | head => exact kX6 | tail _ h => cases h) rfl (.cons sX6 .nil)

theorem castHM : Cast d6F [bnd "X" obj] (.cls (cn "Holder") [tv "X"]) (.cls (cn "MyFoo3") [tv "X"]) :=
  Cast.castDown (Ts' := [tv "X"]) (Sub.subInheritLocal myFoo3D scopeMyFoo3 rfl .subRefl) scopeMyFoo3
    (Sub.subInheritLocal myFoo3D scopeMyFoo3 rfl .subRefl)
    (by intro X h; cases h with | head => exact .head _ | tail _ h => cases h)

theorem consMyFoo3 : Consistent d6F
    (.newLocal (cn "MyFoo3") [.funnel (tn "X")] (cn "Holder") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]) :=
  ⟨_, _, _, _, _, myFoo3D, scopeMyFoo3, rfl, rfl, fun _ => Iff.rfl, by
    intro M h
    cases h with
    | head =>
      exact OverrideOkM.found (Delta'' := []) (T0 := tv "X") (ps := []) (e := ev "x") ⟨_, myFoo3D, rfl, .head _⟩
        scopeMyFoo3 rfl rfl rfl rfl
    | tail _ h => cases h⟩

-- P2: funnelled, with other : Holder<X>, Example 2 is Ok: Holder<X> determines X.
theorem p2 : ClassOk d6F decFixed2 :=
  And.intro (by intro T h; cases h)
  (And.intro (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h)
  (And.intro (by
      intro M h
      cases h with
      | tail _ h => cases h
      | head =>
      exact MethodOk.methodOk (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h) (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h with | head => exact kHolderX | tail _ h => cases h with | head => exact kX6 | tail _ h => cases h with | head => exact kFunXB | tail _ h => cases h)
        (Typing.ifInstanceof (Typing.var rfl) kMyFoo3X castHM
          (Typing.subs
            (Typing.call (C0 := cn "Fun") (Ts0 := [tv "X", tB]) (Delta0 := decFun.Delta)
              (Delta1 := []) (T0 := tv "Y") (ps := [par (tv "X") "x"]) (T0' := tB) (Ts' := [tv "X"])
              (Typing.var rfl) (Scope.dec (.dec mFun6))
              (Exists.intro (.dec decFun) (And.intro (.dec mFun6) (And.intro rfl (.head _)))) rfl rfl rfl
              (by intro T h; cases h) .nil
              (.cons
                (Typing.call (C0 := cn "MyFoo3") (Ts0 := [tv "X"]) (Delta0 := [bnd "X" obj])
                  (Delta1 := []) (T0 := tv "X") (ps := []) (T0' := tv "X") (Ts' := [])
                  (Typing.var rfl) scopeMyFoo3
                  (Exists.intro _ (And.intro myFoo3D (And.intro rfl (.head _)))) rfl rfl rfl
                  (by intro T h; cases h) .nil .nil)
                .nil))
            (kNull (D := decObject) (.head _) rfl) sB6)
          (Typing.subs
            (Typing.newLocal (Delta' := [bnd "X" obj]) consMyFoo3 (RestrictB.funnel (.head _) .nil)
              (by intro X h; cases h) kMyFoo3X kHolderX
              (Typing.newTop (D := decHolder) (es1 := []) (es2 := []) (.dec mH6) kHolderX rfl .nil Typing.newObject)
              (by
                intro M h
                cases h with
                | head => exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; cases h with | head => exact kX6 | tail _ h => cases h) (Typing.var rfl)
                | tail _ h => cases h)
              (overDec w10 (by decide) (by decide) (D0 := decObject) (.head _) rfl rfl (D := decHolder) mH6 rfl rfl
                (by
                  intro M h
                  cases h with
                  | head => exact OverrideOkM.absent (.dec mH6) (by intro h; cases h)
                  | tail _ h => cases h)))
            (kNull (D := decObject) (.head _) rfl)
            (Sub.subInheritLocal myFoo3D scopeMyFoo3 rfl (Sub.subInherit (D := decHolder) (.dec mH6) rfl .subRefl)))))
    (overrideObj (by decide) (by decide) (D0 := decObject) (.head _) rfl rfl)))

-- N4: funnelled, with other : Object<>, Example 2 is still ill typed: Object<> does not determine X.
theorem n4 : Not (ClassOk d6F decFixed2Obj) := by
  intro h
  have hm := h.2.2.1 _ (.head _)
  cases hm with
  | methodOk _ _ ht =>
    cases inv_if ht rfl with
    | intro w hw =>
      cases inv_var hw.ty0 rfl with
      | intro T1 h1 =>
        have e : some obj = some T1 := h1.1
        injection e with e
        subst e
        have e2 := upObj (by decide) (by decide) h1.2
        have hc := hw.cast
        rw [e2] at hc
        exact castObj (C := cn "MyFoo4") (by decide) (by decide) (by decide) (by decide) hc

-- Example 2 with show: X only in the methods of MyFoo6, and in the captured f.

def myFoo6 : Expr :=
  .newLocal (cn "MyFoo6") [] Object [] []
    [meth [] (tv "X") "x" [] (ev "x"),
     meth [] tB "show" [par (.cls (cn "MyFoo6") []) "o"] (call0 (ev "f") "apply" [call0 (ev "o") "x" []])]
def decBroken6 : Dec :=
  { C := cn "Broken6", Delta := [], C' := Object, Ts := [],
    Ms := [meth [bnd "X" obj] obj "m" [par obj "other", par (tv "X") "x", par (tFun (tv "X") tB) "f"]
        (call0 thisE "check" [myFoo6, ev "other"]),
      meth [] obj "check" [par (.cls (cn "MyFoo6") []) "mine", par obj "other"]
        (.ifInst (ev "other") (.cls (cn "MyFoo6") []) (vn "local") (call0 (ev "mine") "show" [ev "local"]) (ev "mine"))],
    Ss := [] }

def d7 : Decls := [decObject, decA, decB, decFun, decAToB, decAsB, decBroken6]

def main6 : Expr :=
  .call (Value.new (cn "Broken6") [] []) [tB] (mn "m")
    [.call (Value.new (cn "Broken6") [] []) [tA] (mn "m") [vA, vA, vAToB], vB, vAsB]

-- W11: Example 2 with show in the core language is well formed.
theorem w11 : WFDecls d7 /\ WFExpr main6 := by decide

theorem r15p : ReducesStar d7 main6 stuckB /\ Stuck d7 stuckB :=
  And.intro
    (ReducesStar.step (red (cArg0 (sAdd rfl rfl rfl rfl) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sFound (D := decBroken6) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sAdd rfl rfl rfl rfl) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sFound (D := decBroken6) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (.tail _ (.head _)) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sElse rfl (noSubEx [cn "A", Object] (by decide) (.head _) (by decide))) rfl rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sFound (D := decBroken6) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sFound (D := decBroken6) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (.tail _ (.head _)) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (sThen rfl .subRefl (by decide)) (by decide))
    (ReducesStar.step (red (sInner (.tail _ (.head _)) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (cArg0 (sInner (.head _) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sFound (D := decAsB) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sSearch (D := decA) (.tail _ (.head _)) (by decide) (by decide) rfl rfl rfl rfl rfl) (by decide))
      ReducesStar.refl))))))))))))))))
    (stuckS (by decide))

-- N5: Example 2 with show is not Ok: MyFoo6 mentions X and captures f, but funnels nothing.
theorem n5 : Not (ProgOk d7 main6) := fun h =>
  h.2.elim fun _ ht => (typeSoundness w11.1 h.1 w11.2 ht r15p.1).2.elim r15p.2.1 fun h' => h'.elim r15p.2.2

-- R15: Example 2 with show reduces to new A<>().[Object<>]onlyB(), which is stuck.
theorem r15 : ReducesStar d7 main6 stuckB /\ Stuck d7 stuckB := r15p

-- Counterexample 3: class generics; javac rejects it, and so does funnelling.

def decBox7 : Dec :=
  { C := cn "NotBroken", Delta := [bnd "X" obj], C' := Object, Ts := [],
    Ms := [meth [] obj "m" [par obj "other", par (tv "X") "x", par (tFun (tv "X") tB) "f"]
      (.ifInst (ev "other") (.cls (cn "MyFoo7") []) (vn "local") (call0 (ev "f") "apply" [call0 (ev "local") "x" []])
        (.newLocal (cn "MyFoo7") [] Object [] [] [meth [] (tv "X") "x" [] (ev "x")]))],
    Ss := [] }
def decBox7F : Dec :=
  { C := cn "NotBrokenF", Delta := [bnd "X" obj], C' := Object, Ts := [],
    Ms := [meth [] obj "m" [par obj "other", par (tv "X") "x", par (tFun (tv "X") tB) "f"]
      (.ifInst (ev "other") (.cls (cn "MyFoo7F") [tv "X"]) (vn "local") (call0 (ev "f") "apply" [call0 (ev "local") "x" []])
        (.newLocal (cn "MyFoo7F") [.funnel (tn "X")] Object [] [] [meth [] (tv "X") "x" [] (ev "x")]))],
    Ss := [] }

def d8 : Decls := [decObject, decA, decB, decFun, decAToB, decAsB, decBox7, decBox7F]

def main7 : Expr :=
  .call (Value.new (cn "NotBroken") [gB] []) [] (mn "m")
    [.call (Value.new (cn "NotBroken") [gA] []) [] (mn "m") [vA, vA, vAToB], vB, vAsB]

-- W12: Counterexample 3 is well formed.
theorem w12 : WFDecls d8 /\ WFExpr main7 := by decide

-- N6: Counterexample 3 is ill typed: MyFoo7 does not funnel the class type variable X.
theorem n6 : Not (ClassOk d8 decBox7) := by
  intro h
  have hm := h.2.2.1 _ (.head _)
  cases hm with
  | methodOk _ _ ht =>
    cases inv_if ht rfl with
    | intro w hw =>
      cases inv_local hw.ty2 rfl with
      | intro w2 hw2 =>
        have hp := hw2.restr
        have hms := hw2.meths _ (.head _)
        generalize w2.Delta' = D' at hp hms
        cases hp
        cases hms with
        | methodOk _ hk _ =>
          have hX : Kind d8 [] (.var (tn "X")) := hk _ (.head _)
          cases hX with
          | kindVar hm => cases hm

-- N7: funnelled, Counterexample 3 is still ill typed: Object<> does not determine X; javac reports this error too.
theorem n7 : Not (ClassOk d8 decBox7F) := by
  intro h
  have hm := h.2.2.1 _ (.head _)
  cases hm with
  | methodOk _ _ ht =>
    cases inv_if ht rfl with
    | intro w hw =>
      cases inv_var hw.ty0 rfl with
      | intro T1 h1 =>
        have e : some obj = some T1 := h1.1
        injection e with e
        subst e
        have e2 := upObj (by decide) (by decide) h1.2
        have hc := hw.cast
        rw [e2] at hc
        exact castObj (C := cn "MyFoo7F") (by decide) (by decide) (by decide) (by decide) hc

-- R16: Counterexample 3 reduces as Example 2: to new A<>().[Object<>]onlyB(), which is stuck.
theorem r16 : ReducesStar d8 main7 stuckB /\ Stuck d8 stuckB :=
  And.intro
    (ReducesStar.step (red (cArg0 (sAdd rfl rfl rfl rfl) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sFound (D := decBox7) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) (by decide))
    (ReducesStar.step (red (cArg0 (sElse rfl (noSubEx [cn "A", Object] (by decide) (.head _) (by decide))) rfl rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sFound (D := decBox7) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (sThen rfl .subRefl (by decide)) (by decide))
    (ReducesStar.step (red (cArg0 (sInner (.head _) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sFound (D := decAsB) (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sSearch (D := decA) (.tail _ (.head _)) (by decide) (by decide) rfl rfl rfl rfl rfl) (by decide))
      ReducesStar.refl)))))))))))
    (stuckS (by decide))

-- The method leak of d4.

def leakMain : Expr :=
  onlyBCall (call0 (.call (Value.new (cn "Broken") [] []) [tB] (mn "leak")
    [.call (Value.new (cn "Broken") [] []) [tA] (mn "mk2") [vA]]) "x" [])

-- R17: leak returns a MyFoo2 built with A<> as a Foo<B<>>; the program reduces to new A<>().[Object<>]onlyB(), which is stuck.
theorem r17 : ReducesStar d4 leakMain stuckB /\ Stuck d4 stuckB :=
  And.intro
    (ReducesStar.step (red (cRecv (cRecv (cArg0 (sAdd rfl rfl rfl rfl) rfl rfl) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (cArg0 (sFound (D := decLeaker) (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl rfl) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (sAdd rfl rfl rfl rfl) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (cRecv (sFound (D := decLeaker) (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))) (.tail _ (.head _)) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl) rfl) (by decide))
    (ReducesStar.step (red (cRecv (sInner (.head _) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl) (by decide))
    (ReducesStar.step (red (sAdd rfl rfl rfl rfl) (by decide))
    (ReducesStar.step (red (sSearch (D := decA) (.tail _ (.head _)) (by decide) (by decide) rfl rfl rfl rfl rfl) (by decide))
      ReducesStar.refl)))))))
    (stuckS (by decide))

def decLeakerF : Dec :=
  { C := cn "Broken", Delta := [], C' := Object, Ts := [],
    Ms := [
      meth [bnd "Y" obj] (.cls (cn "MyFoo2F") [tv "Y"]) "mk2" [par (tv "Y") "y"]
        (.newLocal (cn "MyFoo2F") [.funnel (tn "Y")] (cn "Foo") [tv "Y"] [] [meth [] (tv "Y") "x" [] (ev "y")]),
      meth [bnd "Y" obj] (tFoo (tv "Y")) "leak" [par (.cls (cn "MyFoo2F") [tv "Y"]) "z"] (ev "z")],
    Ss := [] }

def d4F : Decls := [decObject, decA, decB, decFoo, decLeakerF]

def leakMainF : Expr :=
  onlyBCall (call0 (.call (Value.new (cn "Broken") [] []) [tB] (mn "leak")
    [.call (Value.new (cn "Broken") [] []) [tA] (mn "mk2") [vA]]) "x" [])

-- W13: the funnelled leak is well formed.
theorem w13 : WFDecls d4F := by decide

theorem mL4F : List.Mem decLeakerF d4F := (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))
theorem mFoo4F : List.Mem decFoo d4F := (.tail _ (.tail _ (.tail _ (.head _))))

theorem myFoo2FDeclared : Declared d4F
    (.newLocal (cn "MyFoo2F") [.funnel (tn "Y")] (cn "Foo") [tv "Y"] [] [meth [] (tv "Y") "x" [] (ev "y")]) :=
  Declared.newLocal (K := .dec decLeakerF) (.dec mL4F) (.head _) (Exists.intro .hole rfl)

theorem kY4 : Kind d4F [bnd "Y" obj] (tv "Y") := Kind.kindVar (.head _)
theorem sY4 : Sub d4F [bnd "Y" obj] (tv "Y") obj := Sub.subVar (.head _) .subRefl
theorem kFooY4 : Kind d4F [bnd "Y" obj] (tFoo (tv "Y")) := kFooG mFoo4F kY4 sY4

theorem scopeMyFoo2F : Scope d4F (cn "MyFoo2F") [bnd "Y" obj] :=
  Scope.newLocal (C := cn "Broken") (Delta := [])
    (Exists.intro (.dec decLeakerF) (And.intro (.dec mL4F) (And.intro rfl (.head _))))
    (Exists.intro .hole rfl) (Scope.dec (.dec mL4F)) (RestrictB.funnel (.head _) .nil)

theorem kMyFoo2FY : Kind d4F [bnd "Y" obj] (.cls (cn "MyFoo2F") [tv "Y"]) :=
  Kind.kindClass scopeMyFoo2F
    (by intro T h; cases h with | head => exact kY4 | tail _ h => cases h) rfl (.cons sY4 .nil)

theorem consMyFoo2F : Consistent d4F
    (.newLocal (cn "MyFoo2F") [.funnel (tn "Y")] (cn "Foo") [tv "Y"] [] [meth [] (tv "Y") "x" [] (ev "y")]) :=
  ⟨_, _, _, _, _, myFoo2FDeclared, scopeMyFoo2F, rfl, rfl, fun _ => Iff.rfl, by
    intro M h
    cases h with
    | head =>
      exact OverrideOkM.found (Delta'' := []) (T0 := tv "Y") (ps := []) (e := ev "y") ⟨_, myFoo2FDeclared, rfl, .head _⟩
        scopeMyFoo2F rfl rfl rfl rfl
    | tail _ h => cases h⟩

-- P3: funnelled, the class Broken of d4F is Ok: leak takes a MyFoo2F<Y> and returns a Foo<Y>.
theorem p3 : ClassOk d4F decLeakerF :=
  And.intro (by intro T h; cases h)
  (And.intro (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h)
  (And.intro (by
      intro M h
      cases h with
      | head =>
        exact MethodOk.methodOk (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h) (by intro T h; cases h with | head => exact kMyFoo2FY | tail _ h => cases h with | head => exact kY4 | tail _ h => cases h)
          (Typing.newLocal (Delta' := [bnd "Y" obj]) consMyFoo2F (RestrictB.funnel (.head _) .nil)
            (by intro X h; cases h) kMyFoo2FY kFooY4
            (Typing.newTop (D := decFoo) (es1 := []) (es2 := []) (.dec mFoo4F) kFooY4 rfl .nil Typing.newObject)
            (by
              intro M h
              cases h with
              | head => exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; cases h with | head => exact kY4 | tail _ h => cases h) (Typing.var rfl)
              | tail _ h => cases h)
            (overFooG w13 (by decide) (by decide) (.head _) mFoo4F))
      | tail _ h =>
      cases h with
      | tail _ h => cases h
      | head =>
        exact MethodOk.methodOk (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h) (by intro T h; cases h with | head => exact kFooY4 | tail _ h => cases h with | head => exact kMyFoo2FY | tail _ h => cases h)
          (Typing.subs (Typing.var rfl) kFooY4 (Sub.subInheritLocal myFoo2FDeclared scopeMyFoo2F rfl .subRefl)))
    (overrideObj (by decide) (by decide) (D0 := decObject) (.head _) rfl rfl)))

-- N8: funnelled, the main expression of the leak is ill typed: a MyFoo2F<A<>> is passed where a MyFoo2F<B<>> is expected.
theorem leakFMem {T R : Ty} {es : List Expr} {m : String}
    (h : Typing d4F [] [] (.call (Value.new (cn "Broken") [] []) [T] (mn m) es) R) :
    exists Delta1 T0 ps body T0' Ts', List.Mem (Method.mk Delta1 T0 (mn m) ps body) decLeakerF.Ms /\
      [T].length = Delta1.length /\ T0' :: Ts' = Ty.substList (bind Delta1 [T]) (T0 :: ps.map VarDecl.T) /\
      TypingSeq d4F [] [] es Ts' /\ Up d4F [] T0' R :=
  inv_callTop w13 (D := decLeakerF) (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))) rfl rfl rfl (by decide)
    (by decide) h

theorem n8 : Not (exists T, Typing d4F [] [] leakMainF T) := by
  intro h
  cases h with
  | intro T h =>
  cases inv_call h rfl with
  | intro w1 hw1 =>
  cases inv_call hw1.ty0 rfl with
  | intro w2 hw2 =>
  cases leakFMem hw2.ty0 with
  | intro Delta1 h =>
  cases h with
  | intro T0 h =>
  cases h with
  | intro ps h =>
  cases h with
  | intro body h =>
  cases h with
  | intro T0' h =>
  cases h with
  | intro Ts' h =>
  cases names_unique (by decide) h.1 (.tail _ (.head _)) rfl
  have hs := h.2.2.1
  injection hs with e1 e2
  subst e1 e2
  cases h.2.2.2.1 with
  | cons ha _ =>
  cases leakFMem ha with
  | intro Delta1 h =>
  cases h with
  | intro T0 h =>
  cases h with
  | intro ps h =>
  cases h with
  | intro body h =>
  cases h with
  | intro T0' h =>
  cases h with
  | intro Ts' h =>
  cases names_unique (by decide) h.1 (.head _) rfl
  have hs := h.2.2.1
  injection hs with e1 e2
  subst e1 e2
  cases h.2.2.2.2 with
  | inl e =>
    injection e with _ e
    injection e with e
    injection e with e
    exact absurd e (by decide)
  | inr h2 =>
    cases Sub.loc_step w13 myFoo2FDeclared h2.1 with
    | inl e =>
      injection e with _ e
      injection e with e
      injection e with e
      exact absurd e (by decide)
    | inr h3 =>
      rcases h3 with ⟨_, _, _, h3⟩
      exact notSub [cn "Foo", Object] (by decide) (.head _) (by decide) h3

-- Nested local classes: Inner is written in a method of Outer.

def innerExpr : Expr :=
  .newLocal (cn "Inner") [.funnel (tn "X")] (cn "Foo") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]
def outerMethod : Method := meth [] (tv "X") "x" [] (call0 innerExpr "x" [])
def outerExpr : Expr := .newLocal (cn "Outer") [.funnel (tn "X")] (cn "Foo") [tv "X"] [] [outerMethod]
def nestMk : Method := meth [bnd "X" obj] (tFoo (tv "X")) "mk" [par (tv "X") "x"] outerExpr
def decNest : Dec := { C := cn "Nest", Delta := [], C' := Object, Ts := [], Ms := [nestMk], Ss := [] }

def d9 : Decls := [decObject, decA, decB, decFoo, decNest]

def outerK : ClassDecl := .newLocal (cn "Outer") [.funnel (tn "X")] (cn "Foo") [tv "X"] [] [outerMethod]
def innerK : ClassDecl := .newLocal (cn "Inner") [.funnel (tn "X")] (cn "Foo") [tv "X"] [] [meth [] (tv "X") "x" [] (ev "x")]

-- W14: nested local classes are well formed.
theorem w14 : WFDecls d9 := by decide

theorem nestDeclared : Declared d9 (.dec decNest) := .dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))

theorem outerDeclared : Declared d9 outerK :=
  Declared.newLocal (K := .dec decNest) nestDeclared (.head _) (Exists.intro .hole rfl)

-- D1: Inner is declared: it occurs in the method x of Outer, which occurs in the method mk of Nest.
theorem d1Inner : Declared d9 innerK :=
  Declared.newLocal (K := outerK) outerDeclared (.head _) (Exists.intro (.callRecv .hole [] (mn "x") []) rfl)

theorem scopeOuter : Scope d9 (cn "Outer") [bnd "X" obj] :=
  Scope.newLocal (C := cn "Nest") (Delta := [])
    (Exists.intro (.dec decNest) (And.intro nestDeclared (And.intro rfl (.head _))))
    (Exists.intro .hole rfl) (Scope.dec nestDeclared) (RestrictB.funnel (.head _) .nil)

theorem kindA9 : Kind d9 [] tA :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decA) (.dec (.tail _ (.head _))))
    (by intro T h; cases h) rfl .nil

theorem subAObj9 : Sub d9 [] tA obj := Sub.subInherit (D := decA) (.dec (.tail _ (.head _))) rfl .subRefl

-- K1: Inner<A<>> is well kinded: its scope goes through the scope of Outer<X>.
theorem k1 : Kind d9 [] (.cls (cn "Inner") [tA]) :=
  Kind.kindClass (Delta0 := [bnd "X" obj])
    (Scope.newLocal (C := cn "Outer") (Delta := [bnd "X" obj])
      (Exists.intro outerK (And.intro outerDeclared (And.intro rfl (.head _))))
      (Exists.intro (.callRecv .hole [] (mn "x") []) rfl)
      scopeOuter (RestrictB.funnel (.head _) .nil))
    (by intro T h; cases h with
      | head => exact kindA9
      | tail _ h => cases h)
    rfl (.cons subAObj9 .nil)

-- R18: new Nest<>().<A<>>mk(new A<>()).x() reduces to new A<>().
theorem r18 : ReducesStar d9 (call0 (.call (Value.new (cn "Nest") [] []) [tA] (mn "mk") [vA]) "x" []) vA :=
  (ReducesStar.step (red (cRecv (sAdd rfl rfl rfl rfl) rfl) (by decide))
  (ReducesStar.step (red (cRecv (sFound (D := decNest) (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))) (.head _) rfl rfl rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) rfl) (by decide))
  (ReducesStar.step (red (sInner (.head _) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
  (ReducesStar.step (red (sInner (.head _) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    ReducesStar.refl))))

-- Funnels of both forms: after mk<A<>>, the value of Outer2 holds Inner2<Y funnel>, with Y a type variable of g.

def inner2Expr : Expr :=
  .newLocal (cn "Inner2") [.funnel (tn "Y")] (cn "Foo") [tv "Y"] [] [meth [] (tv "Y") "x" [] (ev "y")]
def decMix : Dec :=
  { C := cn "Mix", Delta := [], C' := Object, Ts := [],
    Ms := [meth [bnd "X" obj] (tFoo (tv "X")) "mk" [par (tv "X") "x"]
      (.newLocal (cn "Outer2") [.funnel (tn "X")] (cn "Foo") [tv "X"] []
        [meth [] (tv "X") "x" [] (ev "x"),
         meth [bnd "Y" obj] (tFoo (tv "Y")) "g" [par (tv "Y") "y"] inner2Expr])],
    Ss := [] }

def d10 : Decls := [decObject, decA, decB, decFoo, decMix]

def vOuter2A : Value :=
  .newLocal (cn "Outer2") [gA] (cn "Foo") [gA] []
    [meth [] tA "x" [] vA, meth [bnd "Y" obj] (tFoo (tv "Y")) "g" [par (tv "Y") "y"] inner2Expr]

-- W15: the class table with Outer2 and Inner2 is well formed.
theorem w15 : WFDecls d10 := by decide

-- W16: the value of Outer2<A<>> is well formed; it holds the ground funnel A<> and the funnel Y funnel.
theorem w16 : WFExpr vOuter2A := by decide

-- R19: calling g<B<>> on the value of Outer2<A<>> gives an Inner2<B<>> whose method x returns new B<>().
theorem r19 : ReducesStar d10 (.call vOuter2A [tB] (mn "g") [vB])
    (Value.newLocal (cn "Inner2") [gB] (cn "Foo") [gB] [] [meth [] tB "x" [] vB]) :=
  (ReducesStar.step (red (sInner (.tail _ (.head _)) rfl rfl rfl rfl rfl (by decide) (by decide) (by decide) (by decide)) (by decide))
    ReducesStar.refl)

-- Overriding.

def p1Id : Method := meth [bnd "X" obj] (tv "X") "id" [par (tv "X") "x"] (ev "x")
def p2Id : Method := meth [bnd "Z" obj] (tv "Z") "id" [par (tv "Z") "z"] (ev "z")
def p3Id : Method := meth [bnd "Z" obj] obj "id" [par (tv "Z") "z"] (ev "z")
def p4Id : Method := meth [bnd "Z" tA] (tv "Z") "id" [par (tv "Z") "z"] (ev "z")
def decP1 : Dec := { C := cn "P1", Delta := [], C' := Object, Ts := [], Ms := [p1Id], Ss := [] }
def decP2 : Dec := { C := cn "P2", Delta := [], C' := cn "P1", Ts := [], Ms := [p2Id], Ss := [] }
def decP3 : Dec := { C := cn "P3", Delta := [], C' := cn "P1", Ts := [], Ms := [p3Id], Ss := [] }
def decP4 : Dec := { C := cn "P4", Delta := [], C' := cn "P1", Ts := [], Ms := [p4Id], Ss := [] }

def d11 : Decls := [decObject, decA, decP1, decP2, decP3, decP4]

-- W17: the overriding examples are well formed.
theorem w17 : WFDecls d11 := by decide

-- O1: P2 overrides id with its type variable renamed: Z for X.
theorem o1 : OverrideOkM d11 (.cls (cn "P1") []) p2Id :=
  OverrideOkM.found (Delta'' := [bnd "X" obj]) (T0 := tv "X") (ps := [par (tv "X") "x"]) (e := ev "x")
    ⟨.dec decP1, .dec (.tail _ (.tail _ (.head _))), rfl, .head _⟩
    (Scope.dec (D := decP1) (.dec (.tail _ (.tail _ (.head _))))) rfl rfl rfl rfl

-- O2: P3 changes the return type of id.
theorem o2 : Not (OverrideOkM d11 (.cls (cn "P1") []) p3Id) := by
  intro h
  generalize hT : Ty.cls (cn "P1") [] = T at h
  generalize hM : p3Id = M at h
  cases h with
  | @absent D Ts Delta' T0' m ps' e' hD hm =>
    injection hT with hC
    have e : D = decP1 := dec_unique w17 hC.symm hD (.dec (.tail _ (.tail _ (.head _))))
    subst e
    simp only [p3Id, meth, Method.mk.injEq] at hM
    rw [<- hM.2.2.1] at hm
    exact hm (by decide)
  | @found C Ts Dl Delta' T0' m ps' e' Delta'' T0 ps e hmi hsc hl1 hl2 hc hs =>
    injection hT with hC hTs
    subst hC hTs
    rcases hmi with ⟨K, hK, hKn, hmem⟩
    have eK : K = .dec decP1 := Declared.unique w17 hK (.dec (.tail _ (.tail _ (.head _)))) hKn
    subst eK
    have eD : Dl = decP1.Delta := Scope.dec_eq w17 (.dec (.tail _ (.tail _ (.head _)))) hsc
    subst eD
    cases hmem with
    | tail _ h => cases h
    | head =>
    simp only [p3Id, meth, Method.mk.injEq] at hM
    cases hM with
    | intro e1 hM =>
    cases hM with
    | intro e2 hM =>
    cases hM with
    | intro e3 hM =>
    cases hM with
    | intro e4 e5 =>
    subst e1 e2 e4
    injection hs with h1 h2
    cases h1

theorem o4P4 : Not (OverrideOkM d11 (.cls (cn "P1") []) p4Id) := by
  intro h
  generalize hT : Ty.cls (cn "P1") [] = T at h
  generalize hM : p4Id = M at h
  cases h with
  | @absent D Ts Delta' T0' m ps' e' hD hm =>
    injection hT with hC
    have e : D = decP1 := dec_unique w17 hC.symm hD (.dec (.tail _ (.tail _ (.head _))))
    subst e
    simp only [p4Id, meth, Method.mk.injEq] at hM
    rw [<- hM.2.2.1] at hm
    exact hm (by decide)
  | @found C Ts Dl Delta' T0' m ps' e' Delta'' T0 ps e hmi hsc hl1 hl2 hc hs =>
    injection hT with hC hTs
    subst hC hTs
    rcases hmi with ⟨K, hK, hKn, hmem⟩
    have eK : K = .dec decP1 := Declared.unique w17 hK (.dec (.tail _ (.tail _ (.head _)))) hKn
    subst eK
    have eD : Dl = decP1.Delta := Scope.dec_eq w17 (.dec (.tail _ (.tail _ (.head _)))) hsc
    subst eD
    cases hmem with
    | tail _ h => cases h
    | head =>
    simp only [p4Id, meth, Method.mk.injEq] at hM
    cases hM with
    | intro e1 hM =>
    cases hM with
    | intro e2 hM =>
    cases hM with
    | intro e3 hM =>
    cases hM with
    | intro e4 e5 =>
    subst e1 e2 e4
    injection hc with h1 h2
    injection h1 with h3
    exact absurd h3 (by decide)

-- O3: P2 is Ok.
theorem o3 : ClassOk d11 decP2 :=
  And.intro (by intro T h; cases h)
  (And.intro (by intro T h; cases h with | head => exact (kNull (D := decP1) (.tail _ (.tail _ (.head _))) rfl) | tail _ h => cases h)
  (And.intro (by
      intro M h
      cases h with
      | tail _ h => cases h
      | head =>
      exact MethodOk.methodOk (by intro T h; cases h with | head => exact (kNull (D := decObject) (.head _) rfl) | tail _ h => cases h) (by intro T h; cases h with | head => exact (Kind.kindVar (.head _)) | tail _ h => cases h with | head => exact (Kind.kindVar (.head _)) | tail _ h => cases h)
        (Typing.var rfl))
    (overDec w17 (by decide) (by decide) (D0 := decObject) (.head _) rfl rfl (D := decP1) (.tail _ (.tail _ (.head _))) rfl rfl
      (by intro M h; cases h with | head => exact o1 | tail _ h => cases h))))

-- O4: P3 and P4 are not Ok: P3 changes the return type, P4 changes the bound of the type variable.
theorem o4 : Not (ClassOk d11 decP3) /\ Not (ClassOk d11 decP4) :=
  And.intro (fun h => o2 (h.2.2.2 _ _ _ (.head _) .subRefl)) (fun h => o4P4 (h.2.2.2 _ _ _ (.head _) .subRefl))

-- Checked casts.

-- C3: rule cast-var, then rule cast-down: from X extends Foo<A<>> to MyFoo<A<>>.
theorem c3 : Cast d2 [bnd "X" (tFoo tA)] (tv "X") (.cls (cn "MyFoo") [tA]) :=
  Cast.castVar (.head _)
    (Cast.castDown (Ts' := [tv "Y"])
      (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)
      scopeMyFoo
      (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)
      (by intro X h; cases h with
        | head => exact .head _
        | tail _ h => cases h))

-- C4: rule cast-up: from B<> to Object<>.
theorem c4 : Cast d1 [] tB obj := Cast.castUp (Sub.subInherit (D := decB) (.dec (.tail _ (.tail _ (.head _)))) rfl .subRefl)

-- C5: no checked cast between unrelated classes: from A<> to B<>.
theorem c5 : Not (Cast d1 [] tA tB) := by
  show Not (Cast d1 [] (.cls (cn "A") []) (.cls (cn "B") []))
  intro h
  cases h with
  | castUp hs => exact notSub [cn "A", Object] (by decide) (.head _) (by decide) hs
  | castDown hs1 _ _ _ => exact notSub [cn "B", Object] (by decide) (.head _) (by decide) hs1

-- Fields of a superclass.

def decBase : Dec :=
  { C := cn "Base", Delta := [bnd "X" obj], C' := Object, Ts := [], Ms := [], Ss := [{ T := tv "X", f := fn "f" }] }
def decDerived : Dec :=
  { C := cn "Derived", Delta := [], C' := cn "Base", Ts := [tA], Ms := [], Ss := [{ T := tB, f := fn "g" }] }

def d12 : Decls := [decObject, decA, decB, decBase, decDerived]

def derivedF : Expr := .field (Value.new (cn "Derived") [] [vB, vA]) (fn "f")

theorem declBase : Declared d12 (.dec decBase) := .dec (.tail _ (.tail _ (.tail _ (.head _))))
theorem declDerived : Declared d12 (.dec decDerived) := .dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))

-- R20: the field f of a Derived<> is the field of its superclass Base<A<>>: two steps.
theorem r20 : ReducesStar d12 derivedF vA :=
  ReducesStar.step
    (And.intro
      (Step.topFieldSuper (D := decDerived) (Gs := []) (vs1 := [vB]) (vs := [vA]) declDerived rfl
        (by decide) (by decide) rfl)
      (by decide))
    (ReducesStar.step
      (And.intro
        (Step.topFieldFound (D := decBase) (Gs := [gA]) (vs1 := [vA]) (vs := []) declBase rfl (.head _))
        (by decide))
      ReducesStar.refl)

theorem kindA12 : Kind d12 [] tA :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decA) (.dec (.tail _ (.head _))))
    (by intro T h; cases h) rfl .nil

theorem kindB12 : Kind d12 [] tB :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decB) (.dec (.tail _ (.tail _ (.head _)))))
    (by intro T h; cases h) rfl .nil

theorem kindBaseA : Kind d12 [] (.cls (cn "Base") [tA]) :=
  Kind.kindClass (Delta0 := decBase.Delta) (Scope.dec declBase)
    (by intro T h; cases h with
      | head => exact kindA12
      | tail _ h => cases h)
    rfl (.cons (Sub.subInherit (D := decA) (.dec (.tail _ (.head _))) rfl .subRefl) .nil)

theorem kindDerived : Kind d12 [] (.cls (cn "Derived") []) :=
  Kind.kindClass (Delta0 := []) (Scope.dec declDerived) (by intro T h; cases h) rfl .nil

theorem typA12 : Typing d12 [] [] vA tA :=
  Typing.newTop (D := decA) (es1 := []) (es2 := []) (.dec (.tail _ (.head _))) kindA12 rfl .nil Typing.newObject

theorem typB12 : Typing d12 [] [] vB tB :=
  Typing.newTop (D := decB) (es1 := []) (es2 := []) (.dec (.tail _ (.tail _ (.head _)))) kindB12 rfl .nil
    Typing.newObject

theorem typDerived : Typing d12 [] [] (Value.new (cn "Derived") [] [vB, vA]) (.cls (cn "Derived") []) :=
  Typing.newTop (D := decDerived) (es1 := [vB]) (es2 := [vA]) declDerived kindDerived rfl (.cons typB12 .nil)
    (Typing.newTop (D := decBase) (es1 := [vA]) (es2 := []) declBase kindBaseA rfl (.cons typA12 .nil)
      Typing.newObject)

-- T4: the field f of a Derived<> has type A<>: rule subs to Base<A<>>, then rule field.
theorem t4 : Typing d12 [] [] derivedF tA :=
  Typing.field (D := decBase) (Ts' := [tA]) (T := tv "X")
    (Typing.subs typDerived kindBaseA (Sub.subInherit (D := decDerived) declDerived rfl .subRefl))
    declBase (.head _) rfl

-- Well-formedness requirements one by one.

-- W18: A2: a field f in both Derived2 and its superclass Base.
theorem w18 : Not (A2 [decObject, decA, decBase,
    { C := cn "Derived2", Delta := [], C' := cn "Base", Ts := [tA], Ms := [], Ss := [{ T := tB, f := fn "f" }] }]) := by
  decide

-- W19: A1: a local class named A, as the top-level class A.
theorem w19 : Not (A1 [decObject, decA,
    { C := cn "Clash", Delta := [], C' := Object, Ts := [],
      Ms := [meth [] obj "m" [] (.newLocal (cn "A") [] Object [] [] [])], Ss := [] }]) := by
  decide

-- W20: A11: a ground funnel in Decls.
theorem w20 : Not (A11 [decObject, decA,
    { C := cn "Ground", Delta := [], C' := Object, Ts := [],
      Ms := [meth [] obj "m" [] (.newLocal (cn "L") [.ground gA] Object [] [] [])], Ss := [] }]) := by
  decide

-- W21: A6: the same type variable funnelled twice.
theorem w21 : Not (A6 (classes [decObject,
    { C := cn "Twice", Delta := [], C' := Object, Ts := [],
      Ms := [meth [bnd "X" obj] obj "m" [] (.newLocal (cn "L") [.funnel (tn "X"), .funnel (tn "X")] Object [] [] [])],
      Ss := [] }])) := by
  decide

-- W22: A8: a parameter named this.
def dSelf : Decls := [decObject,
    { C := cn "Self", Delta := [], C' := Object, Ts := [], Ms := [meth [] obj "m" [par obj "this"] thisE], Ss := [] }]

theorem w22 : Not (A8 dSelf.methods (dSelf.flatMap fun D => Method.ifVarsList D.Ms)) := by decide

-- W23: A9: a cycle of superclasses.
theorem w23 : Not (A9 [decObject,
    { C := cn "C3", Delta := [], C' := cn "C4", Ts := [], Ms := [], Ss := [] },
    { C := cn "C4", Delta := [], C' := cn "C3", Ts := [], Ms := [], Ss := [] }]) := by
  decide

-- Renaming by fresh.

def nestedIf : Expr := .ifInst (ev "x") tA (vn "y") (ev "y") (ev "x")
def nestedIf' : Expr := .ifInst (ev "x") tA (vn "y1") (ev "y1") (ev "x")

-- R21: rule ifThen renames the variable y of the inner if into y1, then replaces x.
theorem r21 : Reduces d1 (.ifInst vA tA (vn "x") nestedIf vB) (.ifInst vA tA (vn "y1") (ev "y1") vA) :=
  And.intro
    (Step.ifThen (v := vA) (C' := cn "A") (Ts := []) (Ts' := []) (x := vn "x") (e1 := nestedIf) (e1' := nestedIf')
      (e2 := vB) .subRefl (And.intro (RenE.ifInst .var .var .var) (RenE.ifInst .var .var .var)) (by decide))
    (by decide)

-- The example of Section 4.3: a local class L whose method m calls m on a captured value y of class L.

def lMethod : Method := meth [] obj "m" [par obj "x"] (call0 (ev "y") "m" [ev "x"])
def decK : Dec :=
  { C := cn "K", Delta := [], C' := Object, Ts := [],
    Ms := [meth [] obj "k" [par (.cls (cn "L") []) "y"] (.newLocal (cn "L") [] Object [] [] [lMethod])], Ss := [] }

def d13 : Decls := [decObject, decK]

def vL : Value := .newLocal (cn "L") [] Object [] [] [meth [] obj "m" [par obj "x"] (ev "x")]

def kResult : Value := .newLocal (cn "L") [] Object [] [] [meth [] obj "m" [par obj "x1"] (call0 vL "m" [ev "x1"])]

-- W24: without renaming, the body of k with vL for y would bind x inside a method binding x, against A7.
theorem w24 : Not (Expr.noShadow [] [] (Value.newLocal (cn "L") [] Object [] [] [meth [] obj "m" [par obj "x"] (call0 vL "m" [ev "x"])]) = true) := by
  decide

-- R22: rule topFound renames y into y1 and x into x1, so the copy of m binds x1 and the result is well formed.
theorem r22 : ReducesStar d13 (call0 (Value.new (cn "K") [] []) "k" [vL]) kResult :=
  ReducesStar.step (And.intro (Step.topAddSuper (Gs' := []) (vs := [vL]) rfl) (by decide))
    (ReducesStar.step
      (And.intro
        (Step.topFound (D := decK) (M := meth [] obj "k" [par (.cls (cn "L") []) "y"]
            (.newLocal (cn "L") [] Object [] [] [lMethod]))
          (Gs := []) (Gs' := []) (vs := [vL]) (Delta' := []) (T0 := obj) (ps := [par (.cls (cn "L") []) "y1"])
          (e0 := .newLocal (cn "L") [] Object [] [] [meth [] obj "m" [par obj "x1"] (call0 (ev "y1") "m" [ev "x1"])])
          (.dec (.tail _ (.head _))) (.head _)
          (And.intro
            (.mk (Xs' := []) (xs' := [vn "y1"]) rfl rfl
              (.newLocal .nil (.cons (.mk (Xs' := []) (xs' := [vn "x1"]) rfl rfl (.call .var (.cons .var .nil))) .nil)))
            (.mk (Xs' := []) (xs' := [vn "y"]) rfl rfl
              (.newLocal .nil (.cons (.mk (Xs' := []) (xs' := [vn "x"]) rfl rfl (.call .var (.cons .var .nil))) .nil))))
          rfl rfl (by decide) (by decide) rfl (by decide) (by decide) rfl)
        (by decide))
      ReducesStar.refl)

-- S1: field access on new Object<>() is stuck.
theorem s1 : Stuck d1 (.field (Value.new Object [] []) (fn "f")) :=
  And.intro noValField (fun _ h => noStepField h.1 rfl)

-- The bug of plain alpha-renaming with a substitution that enters a binder of x.

def innerIf (y : String) : Expr := .ifInst vB tB (vn y) (call0 (ev y) "onlyB" []) vB
def outerIf : Expr := .ifInst vA tA (vn "x") (innerIf "y") vB

-- W25: renaming y into x makes the substitution [x = new A<>()] undefined, so rule ifThen has no such instance.
theorem w25 : Not (VSubstDefined [vn "x"] (innerIf "x")) := by decide

-- R23: renaming y into y1, the program reduces to new B<>() in four steps.
theorem r23 : ReducesStar d1 outerIf vB :=
  ReducesStar.step
    (And.intro
      (Step.ifThen (v := vA) (C' := cn "A") (Ts := []) (Ts' := []) (x := vn "x") (e1 := innerIf "y")
        (e1' := innerIf "y1") (e2 := vB) .subRefl
        (And.intro (RenE.ifInst (.new .nil) (.call .var .nil) (.new .nil)) (RenE.ifInst (.new .nil) (.call .var .nil) (.new .nil)))
        (by decide))
      (by decide))
    (ReducesStar.step
      (And.intro
        (Step.ifThen (v := vB) (C' := cn "B") (Ts := []) (Ts' := []) (x := vn "y1")
          (e1 := call0 (ev "y1") "onlyB" []) (e1' := call0 (ev "y1") "onlyB" []) (e2 := vB) .subRefl
          (And.intro (.call .var .nil) (.call .var .nil)) (by decide))
        (by decide))
      (ReducesStar.step
        (And.intro (Step.topAddSuper (Gs' := []) (vs := []) rfl) (by decide))
        (ReducesStar.step
          (And.intro
            (Step.topFound (D := decB) (M := meth [] tB "onlyB" [] vB) (Gs := []) (Gs' := []) (vs := [])
              (Delta' := []) (T0 := tB) (ps := []) (e0 := vB)
              (.dec (.tail _ (.tail _ (.head _)))) (.head _)
              (And.intro (.mk (Xs' := []) (xs' := []) rfl rfl (.new .nil)) (.mk (Xs' := []) (xs' := []) rfl rfl (.new .nil)))
              rfl rfl (by decide) (by decide) rfl (by decide) (by decide) rfl)
            (by decide))
          ReducesStar.refl)))

-- The hypotheses of typeSoundness hold together: DeclsOk for d1 and for d2.

theorem localsList_append (a b : List Expr) :
    Expr.localsList (a ++ b) = Expr.localsList a ++ Expr.localsList b := by
  induction a with
  | nil => simp [Expr.localsList]
  | cons x xs ih => simp [Expr.localsList, ih]

theorem one {A : Type} {a b : A} (h : List.Mem a [b]) : a = b := by
  cases h with
  | head => rfl
  | tail _ h => cases h

theorem noMem {A : Type} {a : A} (h : List.Mem a []) : False := by cases h

theorem occurs_mem (ctx : ExprCtx) (C0 Fs C' Ts es Ms) :
    List.Mem (ClassDecl.newLocal C0 Fs C' Ts es Ms) (ctx.plug (.newLocal C0 Fs C' Ts es Ms)).locals := by
  have key : forall l : List ClassDecl, Membership.mem l (ClassDecl.newLocal C0 Fs C' Ts es Ms) -> List.Mem (ClassDecl.newLocal C0 Fs C' Ts es Ms) l :=
    fun _ h => h
  apply key
  induction ctx with
  | hole => simp [ExprCtx.plug, Expr.locals]
  | callRecv ctx _ _ _ ih => simp [ExprCtx.plug, Expr.locals, ih]
  | callArg _ _ _ _ ctx _ ih => simp [ExprCtx.plug, Expr.locals, localsList_append, Expr.localsList, ih]
  | superRecv ctx _ _ _ _ ih => simp [ExprCtx.plug, Expr.locals, ih]
  | superArg _ _ _ _ _ ctx _ ih => simp [ExprCtx.plug, Expr.locals, localsList_append, Expr.localsList, ih]
  | field ctx _ ih => simp [ExprCtx.plug, Expr.locals, ih]
  | newArg _ _ _ ctx _ ih => simp [ExprCtx.plug, Expr.locals, localsList_append, Expr.localsList, ih]
  | newLocalArg _ _ _ _ _ ctx _ _ ih => simp [ExprCtx.plug, Expr.locals, localsList_append, Expr.localsList, ih]
  | ifCond ctx _ _ _ _ ih => simp [ExprCtx.plug, Expr.locals, ih]
  | ifThen _ _ _ ctx _ ih => simp [ExprCtx.plug, Expr.locals, ih]
  | ifElse _ _ _ _ ctx ih => simp [ExprCtx.plug, Expr.locals, ih]

namespace OkD1

theorem bodies : forall D, List.Mem D d1 -> forall M, List.Mem M D.Ms -> M.body.locals.isEmpty = true := by
  decide

theorem declared {K} (h : Declared d1 K) : exists D, K = .dec D /\ List.Mem D d1 := by
  induction h with
  | dec hD => exact Exists.intro _ (And.intro rfl hD)
  | @newLocal K Delta T0 m ps e C0 Fs C' Ts es Ms _ hM hOcc ih =>
    cases ih with
    | intro D hk =>
    cases hk with
    | intro hk hD =>
    subst hk
    cases hOcc with
    | intro ctx hctx =>
    have hmem := occurs_mem ctx C0 Fs C' Ts es Ms
    rw [<- hctx] at hmem
    have h1 := bodies D hD _ hM
    simp [Method.body] at h1
    rw [h1] at hmem
    exact absurd hmem (fun h => noMem h)

theorem objDec {D} (h : Declared d1 (.dec D)) (hC : D.C = Object) : D = decObject := by
  cases h with
  | dec hmem =>
    have hm : Membership.mem d1 D := hmem
    simp [d1] at hm
    rcases hm with h | h | h | h | h | h <;> subst h <;>
      first | rfl | (simp [decA, decB, decBox, decC1, decC2, cn, Object] at hC)

theorem subObject {Delta S T} (h : Sub d1 Delta S T) : S = .cls Object [] -> T = .cls Object [] := by
  induction h with
  | subRefl => exact id
  | @subInherit D Ts0 T' hD _ _ ih =>
    intro hS
    injection hS with hC hTs
    have := objDec hD hC
    subst this
    subst hTs
    exact ih rfl
  | subInheritLocal hD _ _ _ _ =>
    intro _
    cases declared hD with
    | intro D h2 => exact absurd h2.1 (fun e => by cases e)
  | subVar _ _ _ => intro hS; cases hS

theorem kObj (Delta : Bounds) : Kind d1 Delta obj :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decObject) (.dec (.head _)))
    (by intro T h; cases h) rfl .nil

theorem overrideObj (Delta : Bounds) (Ms : List Method) : OverrideOk d1 Delta obj Ms := by
  intro M C Ts _ hs
  have := subObject hs rfl
  cases this
  cases M with
  | mk _ _ m _ _ => exact OverrideOkM.absent (D := decObject) (.dec (.head _)) (by intro h; cases h)

theorem kB : Kind d1 [] tB :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decB) (.dec (.tail _ (.tail _ (.head _)))))
    (by intro T h; cases h) rfl .nil

theorem kC1 : Kind d1 [] (.cls (cn "C1") []) :=
  Kind.kindClass (Delta0 := [])
    (Scope.dec (D := decC1) (.dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))))
    (by intro T h; cases h) rfl .nil

theorem kX : Kind d1 [bnd "X" obj] (tv "X") := Kind.kindVar (T := obj) (.head _)

theorem okObject : ClassOk d1 decObject :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _) (And.intro (by intro M h; cases h) (overrideObj _ _)))

theorem okA : ClassOk d1 decA :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _) (And.intro (by intro M h; cases h) (overrideObj _ _)))

theorem okB : ClassOk d1 decB :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _)
      (And.intro
        (by
          intro M h
          rw [one h]
          exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; rw [one h]; exact kB)
            (Typing.newTop (D := decB) (es1 := []) (es2 := []) (.dec (.tail _ (.tail _ (.head _)))) kB rfl .nil
              Typing.newObject))
        (overrideObj _ _)))

theorem okC1 : ClassOk d1 decC1 :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _)
      (And.intro
        (by
          intro M h
          rw [one h]
          exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; rw [one h]; exact kindA)
            (Typing.newTop (D := decA) (es1 := []) (es2 := []) (.dec (.tail _ (.head _))) kindA rfl .nil Typing.newObject))
        (overrideObj _ _)))

theorem okC2 : ClassOk d1 decC2 :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kC1) (And.intro (by intro M h; cases h) (by intro M C Ts h; cases h)))

theorem okBox : ClassOk d1 decBox :=
  And.intro (by intro T h; rw [one h]; exact kObj _)
    (And.intro
      (by
        intro T h
        cases h with
        | head => exact kObj _
        | tail _ h => rw [one h]; exact kX)
      (And.intro
        (by
          intro M h
          rw [one h]
          exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; rw [one h]; exact kX)
            (Typing.field (D := decBox) (Ts' := [tv "X"]) (T := tv "X")
              (Typing.var rfl) (.dec (.tail _ (.tail _ (.tail _ (.head _))))) (.head _) rfl))
        (overrideObj _ _)))

theorem declsOk : DeclsOk d1 := by
  intro D h
  have hm : Membership.mem d1 D := h
  simp [d1] at hm
  rcases hm with h | h | h | h | h | h <;> subst h <;>
    first | exact okObject | exact okA | exact okB | exact okBox | exact okC1 | exact okC2

theorem declC1 : Declared d1 (.dec decC1) := .dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))
theorem declC2 : Declared d1 (.dec decC2) := .dec (.tail _ (.tail _ (.tail _ (.tail _ (.tail _ (.head _))))))

theorem kC2 : Kind d1 [] (.cls (cn "C2") []) :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decC2) declC2) (by intro T h; cases h) rfl .nil

theorem typC1 : Typing d1 [] [] (Value.new (cn "C1") [] []) (.cls (cn "C1") []) :=
  Typing.newTop (D := decC1) (es1 := []) (es2 := []) declC1 kC1 rfl .nil Typing.newObject

theorem typC2 : Typing d1 [] [] (Value.new (cn "C2") [] []) (.cls (cn "C2") []) :=
  Typing.newTop (D := decC2) (es1 := []) (es2 := []) declC2 kC2 rfl .nil typC1

theorem subA {Delta S T} (h : Sub d1 Delta S T) : S = tA -> T = tA \/ T = obj := by
  cases h with
  | subRefl => intro hS; exact Or.inl hS
  | @subInherit D Ts0 T' hD _ hs =>
    intro hS
    injection hS with hC hTs
    cases hD with
    | dec hmem =>
      have hm : Membership.mem d1 D := hmem
      simp [d1] at hm
      rcases hm with h | h | h | h | h | h <;> subst h <;>
        simp [decObject, decA, decB, decBox, decC1, decC2, cn, Object] at hC
      exact Or.inr (subObject hs rfl)
  | subInheritLocal hD _ _ _ =>
    intro _
    cases declared hD with
    | intro D h2 => exact absurd h2.1 (fun e => by cases e)
  | subVar _ _ => intro hS; cases hS

end OkD1

namespace OkD2

theorem bodies : forall D, List.Mem D d2 -> Not (D.C = cn "Maker") -> forall M, List.Mem M D.Ms ->
    M.body.locals.isEmpty = true := by
  decide

theorem declared {K} (h : Declared d2 K) : (exists D, K = .dec D /\ List.Mem D d2) \/ K = myFooK := by
  induction h with
  | dec hD => exact Or.inl (Exists.intro _ (And.intro rfl hD))
  | @newLocal K Delta T0 m ps e C0 Fs C' Ts es Ms _ hM hOcc ih =>
    cases hOcc with
    | intro ctx hctx =>
    have hmem := occurs_mem ctx C0 Fs C' Ts es Ms
    rw [<- hctx] at hmem
    cases ih with
    | inl h =>
      cases h with
      | intro D hk =>
      cases hk with
      | intro hk hD =>
      subst hk
      by_cases hC : D.C = cn "Maker"
      case pos =>
        have hDm : Membership.mem d2 D := hD
        simp [d2] at hDm
        rcases hDm with h | h | h | h | h <;> subst h <;> simp [decObject, decA, decB, decFoo, cn, Object] at hC
        have hm := one hM
        simp only [mkMethod] at hm
        cases hm
        have h2 : List.Mem (ClassDecl.newLocal C0 Fs C' Ts es Ms) [myFooK] := by
          simpa [myFooK, myFooBody, Expr.locals, Expr.localsList, Method.localsList, myFooMethod, Method.locals]
            using hmem
        exact Or.inr (one h2)
      case neg =>
        have h1 := bodies D hD hC _ hM
        simp [Method.body] at h1
        rw [h1] at hmem
        exact absurd hmem (fun h => noMem h)
    | inr hk =>
      subst hk
      have hm := one hM
      simp only [myFooMethod] at hm
      cases hm
      exact absurd hmem (fun h => noMem (by simpa [Expr.locals] using h))

theorem decName {D C} (h : Declared d2 (.dec D)) (hC : D.C = C) :
    (C = Object -> D = decObject) /\ (C = cn "Foo" -> D = decFoo) := by
  cases h with
  | dec hmem =>
    have hm : Membership.mem d2 D := hmem
    simp [d2] at hm
    subst hC
    rcases hm with h | h | h | h | h <;> subst h <;> simp [decObject, decA, decB, decFoo, decMaker, cn, Object]

theorem locName {C Fs C' Ts es Ms} (h : Declared d2 (.newLocal C Fs C' Ts es Ms)) : C = cn "MyFoo" := by
  cases declared h with
  | inl h1 =>
    cases h1 with
    | intro D h2 => exact absurd h2.1 (fun e => by cases e)
  | inr hk => simp [myFooK] at hk; exact hk.1

theorem subObject {Delta S T} (h : Sub d2 Delta S T) : S = .cls Object [] -> T = .cls Object [] := by
  induction h with
  | subRefl => exact id
  | @subInherit D Ts0 T' hD _ _ ih =>
    intro hS
    injection hS with hC hTs
    have := (decName hD hC).1 rfl
    subst this
    subst hTs
    exact ih rfl
  | subInheritLocal hD _ _ _ _ =>
    intro hS
    injection hS with hC
    have := locName hD
    rw [this] at hC
    simp [cn, Object] at hC
  | subVar _ _ _ => intro hS; cases hS

theorem subFoo {Delta S T T0} (h : Sub d2 Delta S T) :
    S = .cls (cn "Foo") [T0] -> T = .cls (cn "Foo") [T0] \/ T = .cls Object [] := by
  induction h with
  | subRefl => intro h; exact Or.inl h
  | @subInherit D Ts0 T' hD _ hs _ =>
    intro hS
    injection hS with hC hTs
    have := (decName hD hC).2 rfl
    subst this
    exact Or.inr (subObject hs rfl)
  | subInheritLocal hD _ _ _ _ =>
    intro hS
    injection hS with hC
    have := locName hD
    rw [this] at hC
    simp [cn] at hC
  | subVar _ _ _ => intro hS; cases hS

theorem declObj : Declared d2 (.dec decObject) := .dec (.head _)
theorem declA : Declared d2 (.dec decA) := .dec (.tail _ (.head _))
theorem declB : Declared d2 (.dec decB) := .dec (.tail _ (.tail _ (.head _)))
theorem declFoo : Declared d2 (.dec decFoo) := .dec (.tail _ (.tail _ (.tail _ (.head _))))
theorem declMaker : Declared d2 (.dec decMaker) := .dec (.tail _ (.tail _ (.tail _ (.tail _ (.head _)))))

theorem kObj (Delta : Bounds) : Kind d2 Delta obj :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decObject) declObj) (by intro T h; cases h) rfl .nil
theorem kA (Delta : Bounds) : Kind d2 Delta tA :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decA) declA) (by intro T h; cases h) rfl .nil
theorem kB (Delta : Bounds) : Kind d2 Delta tB :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decB) declB) (by intro T h; cases h) rfl .nil
theorem kMaker (Delta : Bounds) : Kind d2 Delta (.cls (cn "Maker") []) :=
  Kind.kindClass (Delta0 := []) (Scope.dec (D := decMaker) declMaker) (by intro T h; cases h) rfl .nil

theorem overrideObj (Delta : Bounds) (Ms : List Method) : OverrideOk d2 Delta obj Ms := by
  intro M C Ts _ hs
  have := subObject hs rfl
  cases this
  cases M with
  | mk _ _ m _ _ => exact OverrideOkM.absent (D := decObject) declObj (by intro h; cases h)

def dY : Bounds := [bnd "Y" obj]
def dX : Bounds := [bnd "X" obj]

theorem kFoo (Delta : Bounds) (T : Ty) (hk : Kind d2 Delta T) (hs : Sub d2 Delta T obj) :
    Kind d2 Delta (tFoo T) :=
  Kind.kindClass (Delta0 := decFoo.Delta) (Scope.dec declFoo)
    (by intro T' h; rw [one h]; exact hk) rfl (.cons hs .nil)

theorem kY : Kind d2 dY (tv "Y") := Kind.kindVar (T := obj) (.head _)
theorem sY : Sub d2 dY (tv "Y") obj := Sub.subVar (.head _) .subRefl
theorem kX : Kind d2 dX (tv "X") := Kind.kindVar (T := obj) (.head _)
theorem sA : Sub d2 [] tA obj := Sub.subInherit (D := decA) declA rfl .subRefl

theorem typA2 (Delta : Bounds) (g : TypeEnv) : Typing d2 Delta g vA tA :=
  Typing.newTop (D := decA) (es1 := []) (es2 := []) declA (kA _) rfl .nil Typing.newObject

theorem typB2 (Delta : Bounds) (g : TypeEnv) : Typing d2 Delta g vB tB :=
  Typing.newTop (D := decB) (es1 := []) (es2 := []) declB (kB _) rfl .nil Typing.newObject

theorem okObject : ClassOk d2 decObject :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _) (And.intro (by intro M h; cases h) (overrideObj _ _)))

theorem okA : ClassOk d2 decA :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _) (And.intro (by intro M h; cases h) (overrideObj _ _)))

theorem okB : ClassOk d2 decB :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _)
      (And.intro
        (by
          intro M h
          rw [one h]
          exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; rw [one h]; exact kB _) (typB2 _ _))
        (overrideObj _ _)))

theorem okFoo : ClassOk d2 decFoo :=
  And.intro (by intro T h; rw [one h]; exact kObj _)
    (And.intro (by intro T h; rw [one h]; exact kObj _)
      (And.intro
        (by
          intro M h
          rw [one h]
          exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; rw [one h]; exact kX)
            (Typing.call (Delta0 := decFoo.Delta) (Delta1 := []) (T0 := tv "X") (ps := [])
              (e := .call thisE [] (mn "x") []) (Ts' := [])
              (Typing.var rfl) (Scope.dec declFoo)
              (Exists.intro (.dec decFoo) (And.intro declFoo (And.intro rfl (.head _)))) rfl rfl rfl
              (by intro T h; cases h) .nil .nil))
        (overrideObj _ _)))

def gMk : TypeEnv := [{ T := .cls (cn "Maker") [], x := this }, par (tv "Y") "y"]

theorem consistentMyFoo : Consistent d2 myFooK :=
  ⟨[.funnel (tn "Y")], [tv "Y"], [], [myFooMethod], _, myFooDeclared, scopeMyFoo, rfl, rfl, fun _ => Iff.rfl, by
    intro M h
    rw [one h]
    exact OverrideOkM.found (Delta'' := []) (T0 := tv "Y") (ps := []) (e := ev "y")
      ⟨_, myFooDeclared, rfl, .head _⟩ scopeMyFoo rfl rfl rfl rfl⟩

theorem kMyFooY : Kind d2 dY (.cls (cn "MyFoo") [tv "Y"]) :=
  Kind.kindClass (Delta0 := dY)
    (Scope.newLocal (C := cn "Maker") (Delta' := dY) (T0 := tFoo (tv "Y")) (m := mn "mk") (ps := [par (tv "Y") "y"])
      (e := myFooBody) (Delta := [])
      (Exists.intro (.dec decMaker) (And.intro declMaker (And.intro rfl (.head _))))
      (Exists.intro .hole rfl) (Scope.dec declMaker) (RestrictB.funnel (.head _) .nil))
    (by intro T h; rw [one h]; exact kY) rfl (.cons sY .nil)

theorem overrideFoo (Delta : Bounds) (T : Ty) (e : Expr) :
    OverrideOk d2 Delta (tFoo T) [.mk [] T (mn "x") [] e] := by
  intro M C Ts hM hs
  rw [one hM]
  cases subFoo hs rfl with
  | inl h =>
    cases h
    exact OverrideOkM.found (Delta'' := []) (T0 := tv "X") (ps := []) (e := .call thisE [] (mn "x") [])
      ⟨.dec decFoo, declFoo, rfl, .head _⟩ (Scope.dec (D := decFoo) declFoo) rfl rfl rfl rfl
  | inr h => cases h; exact OverrideOkM.absent (D := decObject) declObj (by intro h; cases h)

theorem typMyFoo : Typing d2 dY gMk myFooBody (tFoo (tv "Y")) :=
  Typing.subs
    (Typing.newLocal (Delta' := dY) consistentMyFoo (RestrictB.funnel (.head _) .nil)
      (by intro X h; simp [cod, dY, bnd, obj, Ty.ftvList, Ty.ftv] at h; exact absurd h (fun h => noMem h))
      kMyFooY (kFoo _ _ kY sY)
      (Typing.newTop (D := decFoo) (es1 := []) (es2 := []) declFoo (kFoo _ _ kY sY) rfl .nil Typing.newObject)
      (by
        intro M h
        rw [one h]
        exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; rw [one h]; exact Kind.kindVar (T := obj) (.head _))
          (Typing.var rfl))
      (overrideFoo _ _ _))
    (kFoo _ _ kY sY)
    (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)

theorem okMaker : ClassOk d2 decMaker :=
  And.intro (by intro T h; cases h)
    (And.intro (by intro T h; rw [one h]; exact kObj _)
      (And.intro
        (by
          intro M h
          rw [one h]
          exact MethodOk.methodOk (by intro T h; rw [one h]; exact kObj _)
            (by
              intro T h
              cases h with
              | head => exact kFoo _ _ kY sY
              | tail _ h => rw [one h]; exact kY)
            typMyFoo)
        (overrideObj _ _)))

theorem declsOk : DeclsOk d2 := by
  intro D h
  have hm : Membership.mem d2 D := h
  simp [d2] at hm
  rcases hm with h | h | h | h | h <;> subst h <;>
    first | exact okObject | exact okA | exact okB | exact okFoo | exact okMaker

def mainMk : Expr := .call (Value.new (cn "Maker") [] []) [tA] (mn "mk") [vA]

theorem typMain : Typing d2 [] [] mainMk (tFoo tA) :=
  Typing.call (Delta0 := []) (Delta1 := dY) (T0 := tFoo (tv "Y")) (ps := [par (tv "Y") "y"])
    (e := myFooBody) (Ts' := [tA])
    (Typing.newTop (D := decMaker) (es1 := []) (es2 := []) declMaker (kMaker _) rfl .nil Typing.newObject)
    (Scope.dec declMaker)
    (Exists.intro (.dec decMaker) (And.intro declMaker (And.intro rfl (.head _)))) rfl rfl rfl
    (by intro T h; rw [one h]; exact kA _) (.cons sA .nil)
    (.cons (typA2 _ _) .nil)

theorem typVLocal : Typing d2 [] [] vLocal (tFoo tA) :=
  Typing.subs
    (Typing.newLocal (Delta' := [])
      ⟨[.funnel (tn "Y")], [tv "Y"], [], [myFooMethod], _, myFooDeclared, scopeMyFoo, rfl, rfl, fun _ => Iff.rfl, by
        intro M h
        rw [one h]
        exact OverrideOkM.found (Delta'' := []) (T0 := tv "Y") (ps := []) (e := ev "y")
          ⟨_, myFooDeclared, rfl, .head _⟩ scopeMyFoo rfl rfl rfl rfl⟩
      (RestrictB.ground .nil)
      (by intro X h; cases h)
      (Kind.kindClass (Delta0 := dY)
        (Scope.newLocal (C := cn "Maker") (Delta' := dY) (T0 := tFoo (tv "Y")) (m := mn "mk") (ps := [par (tv "Y") "y"])
          (e := myFooBody) (Delta := [])
          (Exists.intro (.dec decMaker) (And.intro declMaker (And.intro rfl (.head _))))
          (Exists.intro .hole rfl) (Scope.dec declMaker) (RestrictB.funnel (.head _) .nil))
        (by intro T h; rw [one h]; exact kA _) rfl (.cons sA .nil))
      (kFoo _ _ (kA _) sA)
      (Typing.newTop (D := decFoo) (es1 := []) (es2 := []) declFoo (kFoo _ _ (kA _) sA) rfl .nil Typing.newObject)
      (by
        intro M h
        rw [one h]
        exact MethodOk.methodOk (by intro T h; cases h) (by intro T h; rw [one h]; exact kA _) (typA2 _ _))
      (overrideFoo _ _ _))
    (kFoo _ _ (kA _) sA)
    (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)

theorem kMyFooA : Kind d2 [] (.cls (cn "MyFoo") [tA]) :=
  Kind.kindClass (Delta0 := dY)
    (Scope.newLocal (C := cn "Maker") (Delta' := dY) (T0 := tFoo (tv "Y")) (m := mn "mk") (ps := [par (tv "Y") "y"])
      (e := myFooBody) (Delta := [])
      (Exists.intro (.dec decMaker) (And.intro declMaker (And.intro rfl (.head _))))
      (Exists.intro .hole rfl) (Scope.dec declMaker) (RestrictB.funnel (.head _) .nil))
    (by intro T h; rw [one h]; exact kA _) rfl (.cons sA .nil)

theorem castFooMyFoo : Cast d2 [] (tFoo tA) (.cls (cn "MyFoo") [tA]) :=
  Cast.castDown (Ts' := [tv "Y"])
    (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)
    scopeMyFoo
    (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl)
    (by intro X h; cases h with
      | head => exact .head _
      | tail _ h => cases h)

end OkD2

-- M1: the class Maker is Ok.
theorem m1 : ClassOk d2 decMaker := OkD2.okMaker

-- V1: the hypotheses of typeSoundness hold together on d1 and the expression of T1.
theorem v1 : WFDecls d1 /\ DeclsOk d1 /\ WFExpr (.field (Value.new (cn "Box") [gA] [vA]) (fn "val")) /\
    Typing d1 [] [] (.field (Value.new (cn "Box") [gA] [vA]) (fn "val")) tA :=
  And.intro w1 (And.intro OkD1.declsOk (And.intro (by decide) t1))

-- V2: the hypotheses of typeSoundness hold together on d2, with the funnelled local class MyFoo,
-- and new Maker<>().<A<>>mk(new A<>()) : Foo<A<>>.
theorem v2 : WFDecls d2 /\ DeclsOk d2 /\ WFExpr OkD2.mainMk /\ Typing d2 [] [] OkD2.mainMk (tFoo tA) :=
  And.intro w5 (And.intro OkD2.declsOk (And.intro (by decide) OkD2.typMain))

-- V3: the result of R7, a copy of MyFoo in the main expression, has type Foo<A<>>.
theorem v3 : Typing d2 [] [] vLocal (tFoo tA) := OkD2.typVLocal

-- V4: the program of V2 is Ok.
theorem v4 : ProgOk d2 OkD2.mainMk := And.intro OkD2.declsOk (Exists.intro _ OkD2.typMain)

-- R6: rule ifElse.
theorem r6Else : Reduces d1 (.ifInst vA tB (vn "x") (.var (vn "x")) vB) vB :=
  And.intro
    (Step.ifElse (v := vA) (C' := cn "B") (Ts := []) (by
      intro h
      cases h with
      | intro Ts' hs =>
        cases OkD1.subA hs rfl with
        | inl h => simp [tA, cn] at h
        | inr h => simp [obj, cn, Object] at h))
    (by decide)

-- T5: rule call-lb-runtime types the results of R2 and R3.
theorem t5 : Typing d1 [] [] (.superCall (Value.new (cn "C2") [] []) (.cls (cn "C2") []) [] (mn "m") []) tA /\
    Typing d1 [] [] (.superCall (Value.new (cn "C2") [] []) (.cls (cn "C1") []) [] (mn "m") []) tA :=
  And.intro
    (Typing.superCall (D := decC2) (Ts := []) (D0 := decC1) (Ts0 := []) (Delta1 := []) (T0 := tA)
      (ps := []) (e := vA) (Ts' := [])
      (Sub.subInherit (D := decC2) OkD1.declC2 rfl .subRefl) OkD1.declC1
      (Exists.intro (.dec decC1) (And.intro OkD1.declC1 (And.intro rfl (.head _)))) rfl rfl rfl
      OkD1.declC2 OkD1.kC2 (by intro T h; cases h) .nil (.cons OkD1.typC2 .nil))
    (Typing.superCall (D := decC1) (Ts := []) (D0 := decC1) (Ts0 := []) (Delta1 := []) (T0 := tA)
      (ps := []) (e := vA) (Ts' := [])
      .subRefl OkD1.declC1
      (Exists.intro (.dec decC1) (And.intro OkD1.declC1 (And.intro rfl (.head _)))) rfl rfl rfl
      OkD1.declC1 OkD1.kC1 (by intro T h; cases h) .nil
      (.cons (Typing.subs OkD1.typC2 OkD1.kC1 (Sub.subInherit (D := decC2) OkD1.declC2 rfl .subRefl)) .nil))

-- T6: rule if-instanceof with a checked cast by cast-up.
theorem t6 : Typing d1 [] [] (.ifInst vA tA (vn "x") (.var (vn "x")) vA) tA :=
  Typing.ifInstanceof typA kindA (Cast.castUp .subRefl) (Typing.var rfl) typA

-- T7: rule if-instanceof with a checked cast by cast-down, on the copy of MyFoo of R7.
theorem t7 : Typing d2 [] []
    (.ifInst vLocal (.cls (cn "MyFoo") [tA]) (vn "w") (.var (vn "w")) vLocal) (tFoo tA) :=
  Typing.ifInstanceof OkD2.typVLocal OkD2.kMyFooA OkD2.castFooMyFoo
    (Typing.subs (Typing.var rfl) (OkD2.kFoo _ _ (OkD2.kA _) OkD2.sA)
      (Sub.subInheritLocal myFooDeclared scopeMyFoo rfl .subRefl))
    OkD2.typVLocal

def capL (y : VarName) : Expr :=
  .newLocal (cn "L") [] Object [] [] [.mk [] obj (mn "m") [] (.var y)]
def capBefore : Expr := .ifInst vA tA (vn "x") (capL (vn "x")) vB
def capAfter : Expr := .ifInst vA tA this (capL this) vB

-- W26: Fresh accepts renaming the variable x of an if into this, which the method m of the local class captures;
-- the result violates A8.
theorem w26 : Fresh capBefore capAfter /\ Not (A8 capAfter.methods capAfter.ifVars) :=
  And.intro
    (And.intro
      (RenE.ifInst (.new .nil)
        (.newLocal .nil (.cons (.mk (Xs' := []) (xs' := []) rfl rfl .var) .nil)) (.new .nil))
      (RenE.ifInst (.new .nil)
        (.newLocal .nil (.cons (.mk (Xs' := []) (xs' := []) rfl rfl .var) .nil)) (.new .nil)))
    (by decide)

def renamedIf : Expr := .ifInst vA tA (vn "x") (innerIf "x") vB

-- W27: Fresh accepts renaming the inner y of the program of W25 into x; the result violates A7.
theorem w27 : Fresh outerIf renamedIf /\ WFExpr outerIf /\ Not (renamedIf.noShadow [] [] = true) :=
  And.intro
    (And.intro
      (RenE.ifInst (.new .nil) (RenE.ifInst (.new .nil) (.call .var .nil) (.new .nil)) (.new .nil))
      (RenE.ifInst (.new .nil) (RenE.ifInst (.new .nil) (.call .var .nil) (.new .nil)) (.new .nil)))
    (And.intro (by decide) (by decide))

def vZ : Value := .newLocal (cn "L") [] Object [] [] [.mk [] obj (mn "m") [] (.var (vn "z"))]
def eOpen : Expr := .ifInst vZ (.cls (cn "L") []) (vn "x") (.ifInst vA tA (vn "y") (ev "x") (ev "x")) vB

-- W28: a main expression whose value vZ holds the free variable z violates A12.
theorem w28 : Not (eOpen.closed [] [] = true) := by decide

def vT : Value := .newLocal (cn "L") [] Object [] [] [.mk [] (tv "Z") (mn "m") [] thisE]
def eT : Expr :=
  .ifInst vT (.cls (cn "L") []) (vn "x")
    (.newLocal (cn "L2") [] Object [] [] [.mk [bnd "Y" obj] obj (mn "k") [] (ev "x")]) vB

-- W29: a main expression whose value vT holds the free type variable Z violates A12.
theorem w29 : Not (eT.closed [] [] = true) := by decide

end Funnelling.Examples
